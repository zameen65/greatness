begin transaction;
delete Invoice_Movie;
commit;
begin transaction;
insert into Invoice_Movie
(Invoice_Number,Movie_Number)
values(1,1)
insert into Invoice_Movie
(Invoice_Number,Movie_Number)
values(2,2)
insert into Invoice_Movie
(Invoice_Number,Movie_Number)
values(4,3)
insert into Invoice_Movie
(Invoice_Number,Movie_Number)
values(4,4)
insert into Invoice_Movie
(Invoice_Number,Movie_Number)
values(6,5)
insert into Invoice_Movie
(Invoice_Number,Movie_Number)
values(6,6)
insert into Invoice_Movie
(Invoice_Number,Movie_Number)
values(7,7)
insert into Invoice_Movie
(Invoice_Number,Movie_Number)
values(8,8)
insert into Invoice_Movie
(Invoice_Number,Movie_Number)
values(9,9)
insert into Invoice_Movie
(Invoice_Number,Movie_Number)
values(10,10)
insert into Invoice_Movie
(Invoice_Number,Movie_Number)
values(11,11)
insert into Invoice_Movie
(Invoice_Number,Movie_Number)
values(12,12)
insert into Invoice_Movie
(Invoice_Number,Movie_Number)
values(13,13)
insert into Invoice_Movie
(Invoice_Number,Movie_Number)
values(14,14)
insert into Invoice_Movie
(Invoice_Number,Movie_Number)
values(15,1)
insert into Invoice_Movie
(Invoice_Number,Movie_Number)
values(16,1)
insert into Invoice_Movie
(Invoice_Number,Movie_Number)
values(17,1)
insert into Invoice_Movie
(Invoice_Number,Movie_Number)
values(18,1)
commit;
