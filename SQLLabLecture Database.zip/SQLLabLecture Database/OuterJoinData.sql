insert into Customer
(Customer_Number,Customer_First_Name,Customer_Last_Name,
Customer_Mid_Init,Customer_Addr_1,Customer_Addr_2,
Customer_City,Customer_St,Customer_Email,
Customer_Zip,Customer_Zip_4)
Values(20,'Emmalyn','Clogg',NULL,'Lower Butcher Road',NULL,
'Ellington','CT','EK@yahoo.com',06514,9999);
insert into Invoice
(Invoice_Number,Customer_number,invoice_total,
Invoice_Creation_Date,invoice_due_date)
values(25,31,15.22,'12/31/2008','12/31/2008');