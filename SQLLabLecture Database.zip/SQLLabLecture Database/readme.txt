1. Start SQL Server Management Studio and connect to your instance.

2. You will need the appropriate permissions to run these statements.

3. Open CreateDB and make sure that your statement will run against the Master DB. Run the statement and, if it completes successfully, you may continue to the next step.

3. Open SqlLabLecture and make sure that your statement will run against the SQLLabLecture DB. Run the statement and, if it completes successfully, you may continue to the next step.

4. Open Customer and make sure that your statement will run against the SQLLabLecture DB. Run the statement and, if it completes successfully, you may continue to the next step.

5. Open Invoice and make sure that your statement will run against the SQLLabLecture DB. Run the statement and, if it completes successfully, you may continue to the next step.

6. Open Movie and make sure that your statement will run against the SQLLabLecture DB. Run the statement and, if it completes successfully, you may continue to the next step.

7. Open Invoice_Movie and make sure that your statement will run against the SQLLabLecture DB. Run the statement and, if it completes successfully, you may continue to the next step. This step may have some errors but that's OK.

8. Open Phone and make sure that your statement will run against the SQLLabLecture DB. Run the statement and, if it completes successfully, you may continue to the next step. This step may have some errors but that's OK.

9 Open OuterJoinData and make sure that your statement will run against the SQLLabLecture DB. Run the statement and, if it completes successfully, your setup is complete.

10.LectureExamples contains the examples used in the course book.
