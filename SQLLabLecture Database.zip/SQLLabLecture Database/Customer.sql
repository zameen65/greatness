begin transaction;
delete Customer;
commit;
begin transaction;
insert into Customer
(Customer_Number,Customer_First_Name,Customer_Last_Name,
Customer_Mid_Init,Customer_Addr_1,Customer_Addr_2,
Customer_City,Customer_St,Customer_Email,
Customer_Zip,Customer_Zip_4)
Values(1,'Harry','Wenton',NULL,'27 Hillsdale Drive',NULL,
'Ellington','CT','HarryW@yahoo.com',06514,9999);
insert into Customer
(Customer_Number,Customer_First_Name,Customer_Last_Name,
Customer_Mid_Init,Customer_Addr_1,Customer_Addr_2,
Customer_City,Customer_St,Customer_Email,
Customer_Zip,Customer_Zip_4)
Values(2,'Moe','Howard','S','43 East 83rd St','Apt 22',
'New York','NY','MoeH@google.com',10025,1234);
insert into Customer
(Customer_Number,Customer_First_Name,Customer_Last_Name,
Customer_Mid_Init,Customer_Addr_1,Customer_Addr_2,
Customer_City,Customer_St,Customer_Email,
Customer_Zip,Customer_Zip_4)
Values(3,'Curly','Howard','S','43 East 83rd St','Apt 22',
'New York','NY','NyukNyuk@google.com',10025,1234);
insert into Customer
(Customer_Number,Customer_First_Name,Customer_Last_Name,
Customer_Mid_Init,Customer_Addr_1,Customer_Addr_2,
Customer_City,Customer_St,Customer_Email,
Customer_Zip,Customer_Zip_4)
Values(4,'Larry', 'Fine','S','43 East 83rd St','Apt 22',
'New York','NY','LarryF@google.com',10025,1234);
insert into Customer
(Customer_Number,Customer_First_Name,Customer_Last_Name,
Customer_Mid_Init,Customer_Addr_1,Customer_Addr_2,
Customer_City,Customer_St,Customer_Email,
Customer_Zip,Customer_Zip_4)
Values(5,'Shemp','Howard','S','43 East 83rd St','Apt 22',
'New York','NY','ShempH@google.com',10025,1234);
insert into Customer
(Customer_Number,Customer_First_Name,Customer_Last_Name,
Customer_Mid_Init,Customer_Addr_1,Customer_Addr_2,
Customer_City,Customer_St,Customer_Email,
Customer_Zip,Customer_Zip_4)
Values(6,'Herman','Munster',NULL,'1313 Mockingbird Lane',NULL,
'Ridgewood','NJ','ScaryOne@yahoo.com',07114,NULL);
insert into Customer
(Customer_Number,Customer_First_Name,Customer_Last_Name,
Customer_Mid_Init,Customer_Addr_1,Customer_Addr_2,
Customer_City,Customer_St,Customer_Email,
Customer_Zip,Customer_Zip_4)
Values(7,'Fred','Mertz','C','777 Dog St',NULL,
'Wilton','CT','FreddyM@optonline.net',06897,NULL);
insert into Customer
(Customer_Number,Customer_First_Name,Customer_Last_Name,
Customer_Mid_Init,Customer_Addr_1,Customer_Addr_2,
Customer_City,Customer_St,Customer_Email,
Customer_Zip,Customer_Zip_4)
Values(8,'Ethel','Mertz','C','777 Dog St',NULL,
'Wilton','CT','EthelM@optonline.net',06897,NULL);
insert into Customer
(Customer_Number,Customer_First_Name,Customer_Last_Name,
Customer_Mid_Init,Customer_Addr_1,Customer_Addr_2,
Customer_City,Customer_St,Customer_Email,
Customer_Zip,Customer_Zip_4)
Values(9,'Ralph','Kramden','C','777 Dog St',NULL,
'Wilton','CT','RalphK@optonline.net',06897,NULL);
insert into Customer
(Customer_Number,Customer_First_Name,Customer_Last_Name,
Customer_Mid_Init,Customer_Addr_1,Customer_Addr_2,
Customer_City,Customer_St,Customer_Email,
Customer_Zip,Customer_Zip_4)
Values(10,'Alice','Kramden','C','777 Dog St',NULL,
'Wilton','CT','AliceK@optonline.net',06897,NULL);
insert into Customer
(Customer_Number,Customer_First_Name,Customer_Last_Name,
Customer_Mid_Init,Customer_Addr_1,Customer_Addr_2,
Customer_City,Customer_St,Customer_Email,
Customer_Zip,Customer_Zip_4)
Values(11,'Lucy','Ricardo','F','999 Cat St',NULL,
'Wilton','CT','LucyR@optonline.net',06897,NULL);
insert into Customer
(Customer_Number,Customer_First_Name,Customer_Last_Name,
Customer_Mid_Init,Customer_Addr_1,Customer_Addr_2,
Customer_City,Customer_St,Customer_Email,
Customer_Zip,Customer_Zip_4)
Values(12,'Trixie','Norton','F','999 Cat St',NULL,
'Wilton','CT','TrixieN@optonline.net',06897,NULL);
insert into Customer
(Customer_Number,Customer_First_Name,Customer_Last_Name,
Customer_Mid_Init,Customer_Addr_1,Customer_Addr_2,
Customer_City,Customer_St,Customer_Email,
Customer_Zip,Customer_Zip_4)
Values(13,'Madonna',NULL,NULL,'623 Wilshire Blvd',NULL,
'Hollywood','CA','MaterialGirl@comcast.com',90012,9876);
commit;