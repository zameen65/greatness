begin transaction;
delete Movie;
commit;
begin transaction;
insert into Movie
(Movie_Number,Movie_Title,Movie_Type,
Movie_Rating,Movie_Price,Movie_Qty)
Values(1,'Friday 13th, Part 206','Horror',
'NC17',8.97,4);
insert into Movie
(Movie_Number,Movie_Title,Movie_Type,
Movie_Rating,Movie_Price,Movie_Qty)
Values(2,'The Longest Day','Action',
'PG',14.22,2);
insert into Movie
(Movie_Number,Movie_Title,Movie_Type,
Movie_Rating,Movie_Price,Movie_Qty)
Values(3,'Die Hard','Action',
'PG17',6.00,3);
insert into Movie
(Movie_Number,Movie_Title,Movie_Type,
Movie_Rating,Movie_Price,Movie_Qty)
Values(4,'Shane','Western',
NULL,5.55,2);
insert into Movie
(Movie_Number,Movie_Title,Movie_Type,
Movie_Rating,Movie_Price,Movie_Qty)
Values(5,'Maverick','Western',
'pg',4,2);
insert into Movie
(Movie_Number,Movie_Title,Movie_Type,
Movie_Rating,Movie_Price,Movie_Qty)
Values(6,'Psycho','Horror',
NULL,26.17,3);
insert into Movie
(Movie_Number,Movie_Title,Movie_Type,
Movie_Rating,Movie_Price,Movie_Qty)
Values(7,'Frankenstein','Horror',
NULL,15.68,1);
insert into Movie
(Movie_Number,Movie_Title,Movie_Type,
Movie_Rating,Movie_Price,Movie_Qty)
Values(8,'Young Frankenstein','Comedy',
'PG',11.14,5);
insert into Movie
(Movie_Number,Movie_Title,Movie_Type,
Movie_Rating,Movie_Price,Movie_Qty)
Values(9,'Blazing Saddles','Comedy',
'PG',9.14,3);
insert into Movie
(Movie_Number,Movie_Title,Movie_Type,
Movie_Rating,Movie_Price,Movie_Qty)
Values(10,'Babette''s Feast','Foreign',
'PG',11.22,1);
insert into Movie
(Movie_Number,Movie_Title,Movie_Type,
Movie_Rating,Movie_Price,Movie_Qty)
Values(11,'When Harry Met Sally','Romance',
'PG',14.22,3);
insert into Movie
(Movie_Number,Movie_Title,Movie_Type,
Movie_Rating,Movie_Price,Movie_Qty)
Values(12,'Alien',NULL,
'PG',6.21,3);
insert into Movie
(Movie_Number,Movie_Title,Movie_Type,
Movie_Rating,Movie_Price,Movie_Qty)
Values(13,'200 Motels',NULL,
'nc17',.35,1);
insert into Movie
(Movie_Number,Movie_Title,Movie_Type,
Movie_Rating,Movie_Price,Movie_Qty)
Values(14,'Pan''s Labyrinth','Surreal',
'PG',9.99,1);
commit;