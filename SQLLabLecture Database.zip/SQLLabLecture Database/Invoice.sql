--set dateformat mdy
begin transaction;
delete Invoice;
commit;
begin transaction;
insert into Invoice
(Invoice_Number,Customer_number,invoice_total,
Invoice_Creation_Date,invoice_due_date)
values(1,1,12.95,cast('01/01/2004' as datetime2),cast('01/04/2004' as datetime2));
insert into Invoice
(Invoice_Number,Customer_number,invoice_total,
Invoice_Creation_Date,invoice_due_date)
values(2,2,6.20,'01/19/2004','01/22/2004');
insert into Invoice
(Invoice_Number,Customer_number,invoice_total,
Invoice_Creation_Date,invoice_due_date)
values(4,2,9.00,'02/04/2004','02/07/2004');
insert into Invoice
(Invoice_Number,Customer_number,invoice_total,
Invoice_Creation_Date,invoice_due_date)
values(6,5,6.92,'03/17/2004','03/20/2004');
insert into Invoice
(Invoice_Number,Customer_number,invoice_total,
Invoice_Creation_Date,invoice_due_date)
values(7,1,6.20,'05/21/2004','05/24/2004');
insert into Invoice
(Invoice_Number,Customer_number,invoice_total,
Invoice_Creation_Date,invoice_due_date)
values(8,2,14.12,'05/27/2004','05/30/2004');
insert into Invoice
(Invoice_Number,Customer_number,invoice_total,
Invoice_Creation_Date,invoice_due_date)
values(9,1,11.15,'06/30/2004','07/02/2004');
insert into Invoice
(Invoice_Number,Customer_number,invoice_total,
Invoice_Creation_Date,invoice_due_date)
values(10,9,6.20,'07/04/2004','07/07/2004');
insert into Invoice
(Invoice_Number,Customer_number,invoice_total,
Invoice_Creation_Date,invoice_due_date)
values(11,5,6.20,'08/10/2004','08/13/2004');
insert into Invoice
(Invoice_Number,Customer_number,invoice_total,
Invoice_Creation_Date,invoice_due_date)
values(12,5,6.20,'08/12/2004','08/15/2004');
insert into Invoice
(Invoice_Number,Customer_number,invoice_total,
Invoice_Creation_Date,invoice_due_date)
values(13,6,6.20,'08/14/2004','08/17/2004');
insert into Invoice
(Invoice_Number,Customer_number,invoice_total,
Invoice_Creation_Date,invoice_due_date)
values(14,7,6.20,'08/21/2004','08/24/2004');
insert into Invoice
(Invoice_Number,Customer_number,invoice_total,
Invoice_Creation_Date,invoice_due_date)
values(15,7,9.45,'12/31/2004','12/31/2004');
insert into Invoice
(Invoice_Number,Customer_number,invoice_total,
Invoice_Creation_Date,invoice_due_date)
values(16,7,16.50,'12/31/2004','12/31/2004');
insert into Invoice
(Invoice_Number,Customer_number,invoice_total,
Invoice_Creation_Date,invoice_due_date)
values(17,7,12.31,'12/31/2004','12/31/2004');
insert into Invoice
(Invoice_Number,Customer_number,invoice_total,
Invoice_Creation_Date,invoice_due_date)
values(18,7,15.22,'12/31/2004','12/31/2004');
commit;
