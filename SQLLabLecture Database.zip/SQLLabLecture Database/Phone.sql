begin transaction;
delete Customer_Phone;
commit;
begin transaction;
insert into Customer_Phone
(customer_number, customer_phone_no)
values (1,2035551212);
insert into Customer_Phone
(customer_number, customer_phone_no)
values (2,2035551212);
insert into Customer_Phone
(customer_number, customer_phone_no)
values (3,2035551212);
insert into Customer_Phone
(customer_number, customer_phone_no)
values (4,2035551212);
insert into Customer_Phone
(customer_number, customer_phone_no)
values (5,2035551212);
insert into Customer_Phone
(customer_number, customer_phone_no)
values (6,2035551212);
commit;