
CREATE TABLE [Customer]
( 
	[Customer_Number]    smallint  NOT NULL ,
	[Customer_First_Name] nvarchar(25)  NULL ,
	[Customer_Last_Name] varchar(25)  NULL ,
	[Customer_Mid_Init]  char(1)  NULL ,
	[Customer_Addr_1]    varchar(25)  NULL ,
	[Customer_Addr_2]    varchar(25)  NULL ,
	[Customer_City]      varchar(25)  NULL ,
	[Customer_St]        char(2)  NULL ,
	[Customer_Email]     varchar(50)  NULL ,
	[Customer_Zip]       integer  NULL ,
	[Customer_Zip_4]     integer  NULL 
)
go

ALTER TABLE [Customer]
	ADD CONSTRAINT [XPKCustomer] PRIMARY KEY  CLUSTERED ([Customer_Number] ASC)
go

CREATE TABLE [Customer_Phone]
( 
	[Customer_Number]    smallint  NOT NULL ,
	[Customer_Phone_No]  integer  NOT NULL 
)
go

ALTER TABLE [Customer_Phone]
	ADD CONSTRAINT [XPKCustomer_Phone] PRIMARY KEY  CLUSTERED ([Customer_Number] ASC,[Customer_Phone_No] ASC)
go

CREATE TABLE [Invoice]
( 
	[Customer_Number]    smallint  NULL ,
	[Invoice_Number]     integer  NOT NULL ,
	[Invoice_Total]      decimal(5,2)  NULL ,
	[Invoice_Creation_Date] datetime2(0)  NULL ,
	[Invoice_Due_Date]   datetime2(0)  NULL 
)
go

ALTER TABLE [Invoice]
	ADD CONSTRAINT [XPKInvoice] PRIMARY KEY  CLUSTERED ([Invoice_Number] ASC)
go

CREATE TABLE [Invoice_Movie]
( 
	[Invoice_Number]     integer  NOT NULL ,
	[Movie_Number]       integer  NOT NULL ,
	[Movie_Return_Date]  datetime2(0)  NULL 
)
go

ALTER TABLE [Invoice_Movie]
	ADD CONSTRAINT [XPKInvoice_Movie] PRIMARY KEY  CLUSTERED ([Invoice_Number] ASC,[Movie_Number] ASC)
go

CREATE TABLE [Movie]
( 
	[Movie_Number]       integer  NOT NULL ,
	[Movie_Title]        varchar(25)  NULL ,
	[Movie_Type]         char(15)  NULL ,
	[Movie_Rating]       char(4)  NULL ,
	[Movie_Price]        decimal(5,2)  NULL ,
	[Movie_Qty]          integer  NULL 
)
go

ALTER TABLE [Movie]
	ADD CONSTRAINT [XPKMovie] PRIMARY KEY  CLUSTERED ([Movie_Number] ASC)
go


ALTER TABLE [Customer_Phone]
	ADD CONSTRAINT [R_2] FOREIGN KEY ([Customer_Number]) REFERENCES [Customer]([Customer_Number])
		ON DELETE NO ACTION
		ON UPDATE NO ACTION
go


ALTER TABLE [Invoice]
	ADD CONSTRAINT [R_3] FOREIGN KEY ([Customer_Number]) REFERENCES [Customer]([Customer_Number])
		ON DELETE NO ACTION
		ON UPDATE NO ACTION
go


ALTER TABLE [Invoice_Movie]
	ADD CONSTRAINT [R_4] FOREIGN KEY ([Invoice_Number]) REFERENCES [Invoice]([Invoice_Number])
		ON DELETE NO ACTION
		ON UPDATE NO ACTION
go

ALTER TABLE [Invoice_Movie]
	ADD CONSTRAINT [R_5] FOREIGN KEY ([Movie_Number]) REFERENCES [Movie]([Movie_Number])
		ON DELETE NO ACTION
		ON UPDATE NO ACTION
go


CREATE TRIGGER tD_Customer ON Customer FOR DELETE AS
/* ERwin Builtin Trigger */
/* DELETE trigger on Customer */
BEGIN
  DECLARE  @errno   int,
           @errmsg  varchar(255)
    /* ERwin Builtin Trigger */
    /* Customer  Invoice on parent delete no action */
    /* ERWIN_RELATION:CHECKSUM="0001ef58", PARENT_OWNER="", PARENT_TABLE="Customer"
    CHILD_OWNER="", CHILD_TABLE="Invoice"
    P2C_VERB_PHRASE="", C2P_VERB_PHRASE="", 
    FK_CONSTRAINT="R_3", FK_COLUMNS="Customer_Number" */
    IF EXISTS (
      SELECT * FROM deleted,Invoice
      WHERE
        /*  %JoinFKPK(Invoice,deleted," = "," AND") */
        Invoice.Customer_Number = deleted.Customer_Number
    )
    BEGIN
      SELECT @errno  = 30001,
             @errmsg = 'Cannot delete Customer because Invoice exists.'
      GOTO error
    END

    /* ERwin Builtin Trigger */
    /* Customer  Customer_Phone on parent delete no action */
    /* ERWIN_RELATION:CHECKSUM="00000000", PARENT_OWNER="", PARENT_TABLE="Customer"
    CHILD_OWNER="", CHILD_TABLE="Customer_Phone"
    P2C_VERB_PHRASE="", C2P_VERB_PHRASE="", 
    FK_CONSTRAINT="R_2", FK_COLUMNS="Customer_Number" */
    IF EXISTS (
      SELECT * FROM deleted,Customer_Phone
      WHERE
        /*  %JoinFKPK(Customer_Phone,deleted," = "," AND") */
        Customer_Phone.Customer_Number = deleted.Customer_Number
    )
    BEGIN
      SELECT @errno  = 30001,
             @errmsg = 'Cannot delete Customer because Customer_Phone exists.'
      GOTO error
    END


    /* ERwin Builtin Trigger */
    RETURN
error:
    raiserror @errno @errmsg
    rollback transaction
END

go


CREATE TRIGGER tU_Customer ON Customer FOR UPDATE AS
/* ERwin Builtin Trigger */
/* UPDATE trigger on Customer */
BEGIN
  DECLARE  @numrows int,
           @nullcnt int,
           @validcnt int,
           @insCustomer_Number smallint,
           @errno   int,
           @errmsg  varchar(255)

  SELECT @numrows = @@rowcount
  /* ERwin Builtin Trigger */
  /* Customer  Invoice on parent update no action */
  /* ERWIN_RELATION:CHECKSUM="00023ab4", PARENT_OWNER="", PARENT_TABLE="Customer"
    CHILD_OWNER="", CHILD_TABLE="Invoice"
    P2C_VERB_PHRASE="", C2P_VERB_PHRASE="", 
    FK_CONSTRAINT="R_3", FK_COLUMNS="Customer_Number" */
  IF
    /* %ParentPK(" OR",UPDATE) */
    UPDATE(Customer_Number)
  BEGIN
    IF EXISTS (
      SELECT * FROM deleted,Invoice
      WHERE
        /*  %JoinFKPK(Invoice,deleted," = "," AND") */
        Invoice.Customer_Number = deleted.Customer_Number
    )
    BEGIN
      SELECT @errno  = 30005,
             @errmsg = 'Cannot update Customer because Invoice exists.'
      GOTO error
    END
  END

  /* ERwin Builtin Trigger */
  /* Customer  Customer_Phone on parent update no action */
  /* ERWIN_RELATION:CHECKSUM="00000000", PARENT_OWNER="", PARENT_TABLE="Customer"
    CHILD_OWNER="", CHILD_TABLE="Customer_Phone"
    P2C_VERB_PHRASE="", C2P_VERB_PHRASE="", 
    FK_CONSTRAINT="R_2", FK_COLUMNS="Customer_Number" */
  IF
    /* %ParentPK(" OR",UPDATE) */
    UPDATE(Customer_Number)
  BEGIN
    IF EXISTS (
      SELECT * FROM deleted,Customer_Phone
      WHERE
        /*  %JoinFKPK(Customer_Phone,deleted," = "," AND") */
        Customer_Phone.Customer_Number = deleted.Customer_Number
    )
    BEGIN
      SELECT @errno  = 30005,
             @errmsg = 'Cannot update Customer because Customer_Phone exists.'
      GOTO error
    END
  END


  /* ERwin Builtin Trigger */
  RETURN
error:
    raiserror @errno @errmsg
    rollback transaction
END

go




CREATE TRIGGER tD_Customer_Phone ON Customer_Phone FOR DELETE AS
/* ERwin Builtin Trigger */
/* DELETE trigger on Customer_Phone */
BEGIN
  DECLARE  @errno   int,
           @errmsg  varchar(255)
    /* ERwin Builtin Trigger */
    /* Customer  Customer_Phone on child delete no action */
    /* ERWIN_RELATION:CHECKSUM="0001400a", PARENT_OWNER="", PARENT_TABLE="Customer"
    CHILD_OWNER="", CHILD_TABLE="Customer_Phone"
    P2C_VERB_PHRASE="", C2P_VERB_PHRASE="", 
    FK_CONSTRAINT="R_2", FK_COLUMNS="Customer_Number" */
    IF EXISTS (SELECT * FROM deleted,Customer
      WHERE
        /* %JoinFKPK(deleted,Customer," = "," AND") */
        deleted.Customer_Number = Customer.Customer_Number AND
        NOT EXISTS (
          SELECT * FROM Customer_Phone
          WHERE
            /* %JoinFKPK(Customer_Phone,Customer," = "," AND") */
            Customer_Phone.Customer_Number = Customer.Customer_Number
        )
    )
    BEGIN
      SELECT @errno  = 30010,
             @errmsg = 'Cannot delete last Customer_Phone because Customer exists.'
      GOTO error
    END


    /* ERwin Builtin Trigger */
    RETURN
error:
    raiserror @errno @errmsg
    rollback transaction
END

go


CREATE TRIGGER tU_Customer_Phone ON Customer_Phone FOR UPDATE AS
/* ERwin Builtin Trigger */
/* UPDATE trigger on Customer_Phone */
BEGIN
  DECLARE  @numrows int,
           @nullcnt int,
           @validcnt int,
           @insCustomer_Number smallint, 
           @insCustomer_Phone_No integer,
           @errno   int,
           @errmsg  varchar(255)

  SELECT @numrows = @@rowcount
  /* ERwin Builtin Trigger */
  /* Customer  Customer_Phone on child update no action */
  /* ERWIN_RELATION:CHECKSUM="00015710", PARENT_OWNER="", PARENT_TABLE="Customer"
    CHILD_OWNER="", CHILD_TABLE="Customer_Phone"
    P2C_VERB_PHRASE="", C2P_VERB_PHRASE="", 
    FK_CONSTRAINT="R_2", FK_COLUMNS="Customer_Number" */
  IF
    /* %ChildFK(" OR",UPDATE) */
    UPDATE(Customer_Number)
  BEGIN
    SELECT @nullcnt = 0
    SELECT @validcnt = count(*)
      FROM inserted,Customer
        WHERE
          /* %JoinFKPK(inserted,Customer) */
          inserted.Customer_Number = Customer.Customer_Number
    /* %NotnullFK(inserted," IS NULL","select @nullcnt = count(*) from inserted where"," AND") */
    
    IF @validcnt + @nullcnt != @numrows
    BEGIN
      SELECT @errno  = 30007,
             @errmsg = 'Cannot update Customer_Phone because Customer does not exist.'
      GOTO error
    END
  END


  /* ERwin Builtin Trigger */
  RETURN
error:
    raiserror @errno @errmsg
    rollback transaction
END

go




CREATE TRIGGER tD_Invoice ON Invoice FOR DELETE AS
/* ERwin Builtin Trigger */
/* DELETE trigger on Invoice */
BEGIN
  DECLARE  @errno   int,
           @errmsg  varchar(255)
    /* ERwin Builtin Trigger */
    /* Invoice  Invoice_Movie on parent delete no action */
    /* ERWIN_RELATION:CHECKSUM="0002202b", PARENT_OWNER="", PARENT_TABLE="Invoice"
    CHILD_OWNER="", CHILD_TABLE="Invoice_Movie"
    P2C_VERB_PHRASE="", C2P_VERB_PHRASE="", 
    FK_CONSTRAINT="R_4", FK_COLUMNS="Invoice_Number" */
    IF EXISTS (
      SELECT * FROM deleted,Invoice_Movie
      WHERE
        /*  %JoinFKPK(Invoice_Movie,deleted," = "," AND") */
        Invoice_Movie.Invoice_Number = deleted.Invoice_Number
    )
    BEGIN
      SELECT @errno  = 30001,
             @errmsg = 'Cannot delete Invoice because Invoice_Movie exists.'
      GOTO error
    END

    /* ERwin Builtin Trigger */
    /* Customer  Invoice on child delete no action */
    /* ERWIN_RELATION:CHECKSUM="00000000", PARENT_OWNER="", PARENT_TABLE="Customer"
    CHILD_OWNER="", CHILD_TABLE="Invoice"
    P2C_VERB_PHRASE="", C2P_VERB_PHRASE="", 
    FK_CONSTRAINT="R_3", FK_COLUMNS="Customer_Number" */
    IF EXISTS (SELECT * FROM deleted,Customer
      WHERE
        /* %JoinFKPK(deleted,Customer," = "," AND") */
        deleted.Customer_Number = Customer.Customer_Number AND
        NOT EXISTS (
          SELECT * FROM Invoice
          WHERE
            /* %JoinFKPK(Invoice,Customer," = "," AND") */
            Invoice.Customer_Number = Customer.Customer_Number
        )
    )
    BEGIN
      SELECT @errno  = 30010,
             @errmsg = 'Cannot delete last Invoice because Customer exists.'
      GOTO error
    END


    /* ERwin Builtin Trigger */
    RETURN
error:
    raiserror @errno @errmsg
    rollback transaction
END

go


CREATE TRIGGER tU_Invoice ON Invoice FOR UPDATE AS
/* ERwin Builtin Trigger */
/* UPDATE trigger on Invoice */
BEGIN
  DECLARE  @numrows int,
           @nullcnt int,
           @validcnt int,
           @insInvoice_Number integer,
           @errno   int,
           @errmsg  varchar(255)

  SELECT @numrows = @@rowcount
  /* ERwin Builtin Trigger */
  /* Invoice  Invoice_Movie on parent update no action */
  /* ERWIN_RELATION:CHECKSUM="00028b5b", PARENT_OWNER="", PARENT_TABLE="Invoice"
    CHILD_OWNER="", CHILD_TABLE="Invoice_Movie"
    P2C_VERB_PHRASE="", C2P_VERB_PHRASE="", 
    FK_CONSTRAINT="R_4", FK_COLUMNS="Invoice_Number" */
  IF
    /* %ParentPK(" OR",UPDATE) */
    UPDATE(Invoice_Number)
  BEGIN
    IF EXISTS (
      SELECT * FROM deleted,Invoice_Movie
      WHERE
        /*  %JoinFKPK(Invoice_Movie,deleted," = "," AND") */
        Invoice_Movie.Invoice_Number = deleted.Invoice_Number
    )
    BEGIN
      SELECT @errno  = 30005,
             @errmsg = 'Cannot update Invoice because Invoice_Movie exists.'
      GOTO error
    END
  END

  /* ERwin Builtin Trigger */
  /* Customer  Invoice on child update no action */
  /* ERWIN_RELATION:CHECKSUM="00000000", PARENT_OWNER="", PARENT_TABLE="Customer"
    CHILD_OWNER="", CHILD_TABLE="Invoice"
    P2C_VERB_PHRASE="", C2P_VERB_PHRASE="", 
    FK_CONSTRAINT="R_3", FK_COLUMNS="Customer_Number" */
  IF
    /* %ChildFK(" OR",UPDATE) */
    UPDATE(Customer_Number)
  BEGIN
    SELECT @nullcnt = 0
    SELECT @validcnt = count(*)
      FROM inserted,Customer
        WHERE
          /* %JoinFKPK(inserted,Customer) */
          inserted.Customer_Number = Customer.Customer_Number
    /* %NotnullFK(inserted," IS NULL","select @nullcnt = count(*) from inserted where"," AND") */
    select @nullcnt = count(*) from inserted where
      inserted.Customer_Number IS NULL
    IF @validcnt + @nullcnt != @numrows
    BEGIN
      SELECT @errno  = 30007,
             @errmsg = 'Cannot update Invoice because Customer does not exist.'
      GOTO error
    END
  END


  /* ERwin Builtin Trigger */
  RETURN
error:
    raiserror @errno @errmsg
    rollback transaction
END

go




CREATE TRIGGER tD_Invoice_Movie ON Invoice_Movie FOR DELETE AS
/* ERwin Builtin Trigger */
/* DELETE trigger on Invoice_Movie */
BEGIN
  DECLARE  @errno   int,
           @errmsg  varchar(255)
    /* ERwin Builtin Trigger */
    /* Movie  Invoice_Movie on child delete no action */
    /* ERWIN_RELATION:CHECKSUM="00027ddc", PARENT_OWNER="", PARENT_TABLE="Movie"
    CHILD_OWNER="", CHILD_TABLE="Invoice_Movie"
    P2C_VERB_PHRASE="", C2P_VERB_PHRASE="", 
    FK_CONSTRAINT="R_5", FK_COLUMNS="Movie_Number" */
    IF EXISTS (SELECT * FROM deleted,Movie
      WHERE
        /* %JoinFKPK(deleted,Movie," = "," AND") */
        deleted.Movie_Number = Movie.Movie_Number AND
        NOT EXISTS (
          SELECT * FROM Invoice_Movie
          WHERE
            /* %JoinFKPK(Invoice_Movie,Movie," = "," AND") */
            Invoice_Movie.Movie_Number = Movie.Movie_Number
        )
    )
    BEGIN
      SELECT @errno  = 30010,
             @errmsg = 'Cannot delete last Invoice_Movie because Movie exists.'
      GOTO error
    END

    /* ERwin Builtin Trigger */
    /* Invoice  Invoice_Movie on child delete no action */
    /* ERWIN_RELATION:CHECKSUM="00000000", PARENT_OWNER="", PARENT_TABLE="Invoice"
    CHILD_OWNER="", CHILD_TABLE="Invoice_Movie"
    P2C_VERB_PHRASE="", C2P_VERB_PHRASE="", 
    FK_CONSTRAINT="R_4", FK_COLUMNS="Invoice_Number" */
    IF EXISTS (SELECT * FROM deleted,Invoice
      WHERE
        /* %JoinFKPK(deleted,Invoice," = "," AND") */
        deleted.Invoice_Number = Invoice.Invoice_Number AND
        NOT EXISTS (
          SELECT * FROM Invoice_Movie
          WHERE
            /* %JoinFKPK(Invoice_Movie,Invoice," = "," AND") */
            Invoice_Movie.Invoice_Number = Invoice.Invoice_Number
        )
    )
    BEGIN
      SELECT @errno  = 30010,
             @errmsg = 'Cannot delete last Invoice_Movie because Invoice exists.'
      GOTO error
    END


    /* ERwin Builtin Trigger */
    RETURN
error:
    raiserror @errno @errmsg
    rollback transaction
END

go


CREATE TRIGGER tU_Invoice_Movie ON Invoice_Movie FOR UPDATE AS
/* ERwin Builtin Trigger */
/* UPDATE trigger on Invoice_Movie */
BEGIN
  DECLARE  @numrows int,
           @nullcnt int,
           @validcnt int,
           @insInvoice_Number integer, 
           @insMovie_Number integer,
           @errno   int,
           @errmsg  varchar(255)

  SELECT @numrows = @@rowcount
  /* ERwin Builtin Trigger */
  /* Movie  Invoice_Movie on child update no action */
  /* ERWIN_RELATION:CHECKSUM="00029a73", PARENT_OWNER="", PARENT_TABLE="Movie"
    CHILD_OWNER="", CHILD_TABLE="Invoice_Movie"
    P2C_VERB_PHRASE="", C2P_VERB_PHRASE="", 
    FK_CONSTRAINT="R_5", FK_COLUMNS="Movie_Number" */
  IF
    /* %ChildFK(" OR",UPDATE) */
    UPDATE(Movie_Number)
  BEGIN
    SELECT @nullcnt = 0
    SELECT @validcnt = count(*)
      FROM inserted,Movie
        WHERE
          /* %JoinFKPK(inserted,Movie) */
          inserted.Movie_Number = Movie.Movie_Number
    /* %NotnullFK(inserted," IS NULL","select @nullcnt = count(*) from inserted where"," AND") */
    
    IF @validcnt + @nullcnt != @numrows
    BEGIN
      SELECT @errno  = 30007,
             @errmsg = 'Cannot update Invoice_Movie because Movie does not exist.'
      GOTO error
    END
  END

  /* ERwin Builtin Trigger */
  /* Invoice  Invoice_Movie on child update no action */
  /* ERWIN_RELATION:CHECKSUM="00000000", PARENT_OWNER="", PARENT_TABLE="Invoice"
    CHILD_OWNER="", CHILD_TABLE="Invoice_Movie"
    P2C_VERB_PHRASE="", C2P_VERB_PHRASE="", 
    FK_CONSTRAINT="R_4", FK_COLUMNS="Invoice_Number" */
  IF
    /* %ChildFK(" OR",UPDATE) */
    UPDATE(Invoice_Number)
  BEGIN
    SELECT @nullcnt = 0
    SELECT @validcnt = count(*)
      FROM inserted,Invoice
        WHERE
          /* %JoinFKPK(inserted,Invoice) */
          inserted.Invoice_Number = Invoice.Invoice_Number
    /* %NotnullFK(inserted," IS NULL","select @nullcnt = count(*) from inserted where"," AND") */
    
    IF @validcnt + @nullcnt != @numrows
    BEGIN
      SELECT @errno  = 30007,
             @errmsg = 'Cannot update Invoice_Movie because Invoice does not exist.'
      GOTO error
    END
  END


  /* ERwin Builtin Trigger */
  RETURN
error:
    raiserror @errno @errmsg
    rollback transaction
END

go




CREATE TRIGGER tD_Movie ON Movie FOR DELETE AS
/* ERwin Builtin Trigger */
/* DELETE trigger on Movie */
BEGIN
  DECLARE  @errno   int,
           @errmsg  varchar(255)
    /* ERwin Builtin Trigger */
    /* Movie  Invoice_Movie on parent delete no action */
    /* ERWIN_RELATION:CHECKSUM="000106d1", PARENT_OWNER="", PARENT_TABLE="Movie"
    CHILD_OWNER="", CHILD_TABLE="Invoice_Movie"
    P2C_VERB_PHRASE="", C2P_VERB_PHRASE="", 
    FK_CONSTRAINT="R_5", FK_COLUMNS="Movie_Number" */
    IF EXISTS (
      SELECT * FROM deleted,Invoice_Movie
      WHERE
        /*  %JoinFKPK(Invoice_Movie,deleted," = "," AND") */
        Invoice_Movie.Movie_Number = deleted.Movie_Number
    )
    BEGIN
      SELECT @errno  = 30001,
             @errmsg = 'Cannot delete Movie because Invoice_Movie exists.'
      GOTO error
    END


    /* ERwin Builtin Trigger */
    RETURN
error:
    raiserror @errno @errmsg
    rollback transaction
END

go


CREATE TRIGGER tU_Movie ON Movie FOR UPDATE AS
/* ERwin Builtin Trigger */
/* UPDATE trigger on Movie */
BEGIN
  DECLARE  @numrows int,
           @nullcnt int,
           @validcnt int,
           @insMovie_Number integer,
           @errno   int,
           @errmsg  varchar(255)

  SELECT @numrows = @@rowcount
  /* ERwin Builtin Trigger */
  /* Movie  Invoice_Movie on parent update no action */
  /* ERWIN_RELATION:CHECKSUM="00012b77", PARENT_OWNER="", PARENT_TABLE="Movie"
    CHILD_OWNER="", CHILD_TABLE="Invoice_Movie"
    P2C_VERB_PHRASE="", C2P_VERB_PHRASE="", 
    FK_CONSTRAINT="R_5", FK_COLUMNS="Movie_Number" */
  IF
    /* %ParentPK(" OR",UPDATE) */
    UPDATE(Movie_Number)
  BEGIN
    IF EXISTS (
      SELECT * FROM deleted,Invoice_Movie
      WHERE
        /*  %JoinFKPK(Invoice_Movie,deleted," = "," AND") */
        Invoice_Movie.Movie_Number = deleted.Movie_Number
    )
    BEGIN
      SELECT @errno  = 30005,
             @errmsg = 'Cannot update Movie because Invoice_Movie exists.'
      GOTO error
    END
  END


  /* ERwin Builtin Trigger */
  RETURN
error:
    raiserror @errno @errmsg
    rollback transaction
END

go


