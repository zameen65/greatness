﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;


namespace Final
{
    class Final
    {
        static void Main(string[] args)
        {
            try
            {
                using (SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["conn"].ConnectionString))
                {
                    string sql = "SELECT StudentID, StudentName, StudentResult " +
                             
                            "FROM student ";
                    //Console.WriteLine("Please enter a customer ID (5 characters):");
                    //sql += "'" + Console.ReadLine().Trim() + "'";
                    //CustomerID is char so we need to enclose the returned value in single quotes
                    SqlDataAdapter adapter = new SqlDataAdapter(sql, conn);
                    //this form of the constructor takes a string representing the SELECT
                    //statement and the SqlConnection object built from App.Config
                    DataSet ds = new DataSet();
                    //instantiate  new DataSet object
                    adapter.Fill(ds);
                    //the SqlDataAdapter will put the result set from the query into the DataSet
                    if (ds.Tables[0].Rows.Count == 0)
                    //test the FIRST table Property in the DataSet and ask if the Rows Property has a 
                    //Count Property equal to 0 (null set)
                    {
                        Console.WriteLine("None found");
                    }
                    else
                    {
                        foreach (DataRow row in ds.Tables[0].Rows)
                            // foreach requires the IEnumerable interface
                            //this is a read (flat file) / fetch (RDBMS) loop
                            //Console.WriteLine(row[0] + ", " + row[1] + ", " + row[2]);
                            Console.WriteLine(
                                    "StudentID: {0}\nStudent Name: {1}\nStudent Result: {2}\n" ,
                                     row["StudentID"], row["StudentName"],
                                    row["StudentResult"]);
                        //use row["Column Name"] from base table

                    }
                    int n = 0;
                    int m = 1;
                    int y = m / n;
                    Console.ReadLine();
                }
            }
            catch (SqlException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (Exception ex)
            //this catch block is ALWAYS last
            {
                Console.WriteLine(ex.Message);
            }
            finally
            {
                Console.WriteLine("I don't do nuttin', Honey");
            }
        }
    }
}
