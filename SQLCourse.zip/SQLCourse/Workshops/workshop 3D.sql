select DEPTName, DEPTNO --, ADMRDEPT  use this comment to verify its from A00
from DEPT
where ADMRDEPT='A00';