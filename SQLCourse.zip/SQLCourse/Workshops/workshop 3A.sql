select * from emp
select * from dept
select * from PROJ