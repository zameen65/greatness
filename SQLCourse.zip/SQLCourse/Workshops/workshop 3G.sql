select *
from EMP
where (HIREDATE< '01/01/1960' and EDLEVEL>=16)
or
		(hiredate>='01/01/1960' and  EDLEVEL<16)


