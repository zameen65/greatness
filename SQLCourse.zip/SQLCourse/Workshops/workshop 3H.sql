select distinct WORKDEPT
from EMP