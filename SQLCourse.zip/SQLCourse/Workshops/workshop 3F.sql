select FIRSTNME, LASTNAME, SALARY/12 as "monthly salary"
from EMP
where SALARY/12 >= 30000
order by LASTNAME asc