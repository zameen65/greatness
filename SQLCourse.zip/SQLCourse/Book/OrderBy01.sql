select Customer_Last_Name As ln, Customer_First_Name As fn
from Customer
--the order is based on an ordinal reference
--Not considered best proactice
--use asc desc explictely to advoid confusion
--Not recommed
order by ln ASC, 2 Desc--don't do this