select Customer_Last_Name, Customer_First_Name
from Customer
order by 1, 2