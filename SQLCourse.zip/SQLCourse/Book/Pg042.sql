select Invoice_Total, 
Invoice_Total + 3  AS "Penalty Charge"
from invoice