select distinct Customer_Last_Name, Customer_First_Name
from Customer
