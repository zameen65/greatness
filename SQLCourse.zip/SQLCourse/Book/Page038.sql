select * -- show all columns
from customer

/*
all rows 
*/
