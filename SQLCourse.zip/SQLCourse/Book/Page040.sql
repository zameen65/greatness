--what columns/ expressions do you want
select Customer_Last_Name ,Customer_First_Name
--from what?
from customer