select distinct Customer_Last_Name
from Customer
--result set is sorted and duplicated are removes