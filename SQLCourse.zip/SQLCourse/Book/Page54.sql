select Customer_Last_Name As ln, Customer_First_Name As fn
from Customer
--use the renames column on the order by
-- the renamed column may only be referenced in the order by clause
--Not any other clauses
order by ln ASC, fn Desc