select Movie_Type , Movie_Rating, Movie_Title
from Movie
order by Movie_Type asc, Movie_Rating asc, Movie_Title asc
-- when changing  ordi
-- make sure your projection makes sense for the order by