select Customer_Last_Name, Customer_St, Customer_First_Name
from Customer

where Customer_Last_Name is not null