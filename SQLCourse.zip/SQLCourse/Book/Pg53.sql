--the "projectio" is last n ame followed by first name
--projectiom is order of columns left to right
select  Customer_Last_Name, Customer_First_Name

from Customer
--order by deters sequence of rows top to bottom
--the primary key is last name
--secondary is first name
--first names or ordered within last name 
--specify the defaluts for clarify
--if we had a where clase, it would go here
--order by primary sort key, secondary sort key
--use asc desc explictel to avoid confusion
order by Customer_Last_Name asc, Customer_First_Name desc