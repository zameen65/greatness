select distinct Customer_Last_Name, Customer_First_Name
from Customer
--distict applies to the entire row not just the first column after