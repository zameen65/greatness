select Customer_Last_Name As ln, Customer_First_Name As fn
from Customer
--the order is based on an ordinal reference
--Not considered best proactice
order by 1 ASC, 2 Desc