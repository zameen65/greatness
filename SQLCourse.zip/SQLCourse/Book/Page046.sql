--what columns do we want, only there will be on result set
select Customer_Last_Name, Customer_First_Name, Customer_St
--where do the columns live
from Customer
--filter by customer st, only ct willl be on results\
where customer_st='ct' or Customer_St='st'
--where cu...='ct' is a predicate
--operand 1 operator operand 2
and Customer_Last_Name = 'mertz'  or Customer_Last_Name='howard'