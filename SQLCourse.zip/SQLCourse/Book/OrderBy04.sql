select  lastname, FIRSTNME, SALARY/12 as "Monthly Salary"
--use double quotes to rename expession with spaces
--use single qoutes to enlcose text strings
from emp 
where workdept='a00'
--order by SALARY/12 desc
--use renamed column because that's what shows up the resuly set
order by "monthly salary" desc