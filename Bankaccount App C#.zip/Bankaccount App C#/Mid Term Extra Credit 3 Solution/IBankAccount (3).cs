﻿using System;

namespace MidTerm
{
    public interface IBankAccount
    {
        void Deposit(decimal amount);        
        bool Withdraw(decimal amount);
        decimal Balance
        {
            get;
        }
    }
}