﻿using System;
using MidTerm;
//using MidTerm.BozoNationalBank;
//using MidTerm.StoogeAmalgamatedBank

namespace MidTerm
{
    class InsufficientFundsException : Exception
    {
    public InsufficientFundsException() : base() { }
    public InsufficientFundsException(string message) : base(message) { }
    }
}
