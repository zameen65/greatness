﻿using System;

class Exercise
{
        static double Operand1, Operand2;
        static double Fred = 0.00;
        static char Operator;
        

    static void Main()
    {
        //string s;
        Console.WriteLine("This program allows you to perform an operation on two numbers");
        try
        {
            doWork();
        }

        catch (FormatException ex)
        {
            Console.WriteLine(ex.Message);
        }
        catch (Exception ex)
        {
            Console.WriteLine(ex.Message);
        }
    }
      static void doWork() //knew method called do word
    { 
        

            //  Console.WriteLine("To proceed, enter a number, an operator, and a number:");
            //  s = Console.ReadLine();
            // string[] values = s.Split(' ');
            Console.WriteLine("To proceed, enter a number");
            Operand1 = double.Parse(Console.ReadLine());
            //ReadLine retrieves the data
            //Convert.ToDouble will also work for conversion
            Console.WriteLine("To proceed, enter an operator");
            Operator = char.Parse(Console.ReadLine());
            //Operator = Console.ReadLine();
            Console.WriteLine("To proceed, enter a number");
            Operand2 = double.Parse(Console.ReadLine());


            //Console.WriteLine(Operand1.ToString());
            //Console.WriteLine(Operator);
            //Console.WriteLine(Operand2.ToString());

            if (Operator == '+' || Operator == '-' || Operator == '*' || Operator == '/')
            //    throw new Exception(Operator.ToString());
            {
                Console.WriteLine("Operation OK - if");
            }
            else
            {
                Console.WriteLine("Bad Operation - if");
            }


            switch (Operator)
            {
                case '+':
                    Fred = Operand1 + Operand2;
                    break;

                case '-':
                    Fred = Operand1 - Operand2;
                    break;

                case '*':
                    Fred = Operand1 * Operand2;
                    break;

                case '/':
                    Fred = Operand1 / Operand2;
                    break;

                default:
                    //Console.WriteLine("Bad Operation - switch");
                    throw new Exception("Invalid Operation");
                    break;
            }
            Console.WriteLine("\n{0} {1} {2} = {3}", Operand1, Operator, Operand2, Fred);
       
    }
}



