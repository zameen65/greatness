﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Labinhertence2A
{
    class Reptile : Animal
    {
        //private bool isVenomous;
        
        // this is a property
        //where is the Field?
        //the compeller  has defined for us and we don't see the name
        //USE AUTOMATICAL GENERATED PROPERTIES WHEREVER POSSIBLE
        // this means any place where you don't need to verify a value
        public bool IsVenomous
        {
            get;
            set;
        }
        public Reptile()
         //:base is OUTSIDE the body of the constructor
         : base()
        {
            IsVenomous = false;
            Console.WriteLine("reptile noargs constructor called");
        }
        public Reptile(string arg1)
            : base(arg1)
        {
            IsVenomous = false;
            Console.WriteLine("Reptile string constructor called");
            Console.WriteLine(arg1);
        }

        public Reptile(string arg1, string arg2)
            : base(arg1, arg2)
        {
            IsVenomous = false;
            Console.WriteLine("Reptile string constructor called");
            Console.WriteLine(arg1);
            Console.WriteLine(arg2);
        }
        public Reptile(string arg1, string arg2, bool arg3)
           : base(arg1, arg2)
        {     //there is no contructor in animal in that takes 3 args
            IsVenomous = arg3;
            Console.WriteLine("Reptile string constructor called");
            Console.WriteLine(arg3);
        }

        public override void print()
        {
            Console.WriteLine("message from reptile print");
        }
        /*
        //put the getters and setters in the class where the Field is declared
        public bool getIsVenomous()
        {
            return IsVenomous;
        }

        public void setIsVenomous(bool isVenomous)
        {
            this.IsVenomous = isVenomous;
        }
        */
    }
}
