﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Labinhertence2A
{
    class Animal
    //part 1 uses inheritance, 
    //contains 2 constructors for each class and a print method


    {
        public string AnimalPhylum
        {
            get;
            set;
        }
        public string AnimalType
        {
            get;
            set;
        }

        public Animal()
        {//fields are initialized btythe construtor
            Console.WriteLine("Animal noargs constructor called");
        }
        public Animal(string arg1)
        {//fields are initialized by the construtir
            Console.WriteLine("Animal string constructor called");
            Console.WriteLine(arg1);

        }

        public Animal(string arg1, string arg2)
        {
            AnimalType = arg2;
            AnimalPhylum = arg1;
            Console.WriteLine("Animal string constructor called");
            Console.WriteLine(arg1);
            Console.WriteLine(arg2);
        }
        //virtual for override by descinding classes
        public virtual void print()
        {
            Console.WriteLine("message from animal print");
        }

        /* //getters and setters
        public string getAnimalType()
        {
            return AnimalType;
        }

        public void setAnimalType(string AnimalType)
        {
            ///use this to distinguish feild from arg
            this.AnimalType = AnimalType;
        }

        public string getAnimalPhylum()
        {
            return AnimalPhylum;
        }

        public void setAnimalPhylum(string AnimalPhylum)
        {
            this.AnimalPhylum = AnimalPhylum;
        }
        */
        
    }
}
