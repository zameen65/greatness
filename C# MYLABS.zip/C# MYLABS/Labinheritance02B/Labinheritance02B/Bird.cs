﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Labinhertence2A
{
    class Bird : Animal
    {
        public Bird()
           //:base is OUTSIDE the body of the constructor
           : base()
        {
            Console.WriteLine("Bird noargs constructor called");
        }
        public Bird(string arg1)
            : base(arg1)
        {
            Console.WriteLine("Bird string constructor called");
            Console.WriteLine(arg1);
        }

        public Bird(string arg1, string arg2)
            : base(arg1, arg2)
        {
            Console.WriteLine("Bird string constructor called");
            Console.WriteLine(arg1);
        }
        public override void print()
        {
            Console.WriteLine("message from bird print");
        }

    }
}
