﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DefineMethods1
{
    class Program
    {
         //declaring
         static int int1, int2, int3;
        static string text1 = "aaaa";
        static string text2 = "bbbb";
        static string text3 = "cccc";
        static float float1 = 19.999f;
        static  decimal decimal1 = 19.999m;
        static  long long1 = 19;



        static void Main(string[] args)
        {

           //assigng
            int1 = int2 = int3 = 10;
            consoleDisplay(text1, int1);
            int1 = 42;
            text1 = "Louie";
            consoleDisplay(text1, int1);
            consoleDisplay(text1, float1);
            consoleDisplay(text1, decimal1);
            consoleDisplay(text1, long1);




        }
        static void consoleDisplay(string message, int value)
        {
            Console.Write(message + " ");
            Console.WriteLine(value);
        }
        static void consoleDisplay(string message, float value)
        {
            Console.Write(message + " ");
            Console.WriteLine(value);
        }
        static void consoleDisplay(string message, decimal value)
        {
            Console.Write(message + " ");
            Console.WriteLine(value);
        }
        static void consoleDisplay(string message,long value)
        {
            Console.Write(message + " ");
            Console.WriteLine(value);
        }

    }
}
