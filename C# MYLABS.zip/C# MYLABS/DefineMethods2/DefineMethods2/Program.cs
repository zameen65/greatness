﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DefineMethods2
{
    class Program
    {
        static void Main(string[] args)
        {
                Console.WriteLine("Enter a radius");
                int radius = int.Parse(Console.ReadLine());
                double area = calcArea(radius);
                Console.Write("The area is ");
                Console.WriteLine(area); 
            }
            static double calcArea(int louie)
            {
                return (louie * louie * Math.PI);
            }
        }
    }
