﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LabInheritance02
{
    class Program
    {
        static void Main(string[] args)
        {
            //instaniate animals with all constructors
            //define name and pointer in stack
            //Animal animal
           
            Animal a1 = new Animal();
            Animal a2 = new Animal("I'm am a animal");
            a2.print("message from animal print");
            //print is not static

            Mammal m1 = new Mammal();
            Mammal m2 = new Mammal("I'm am a human");
            Mammal m3 = new Mammal("mammal","human");
            m2.print("message from mammal print");

            Bird b1 = new Bird();
            Bird b2 = new Bird("I'm am a Hawk");
            Bird b3 = new Bird("bird","parrot");
            b2.print("message from bird print");
            // or a2.print()

            Reptile r1 = new Reptile();
            Reptile r2 = new Reptile("I'm am a snake");
            Reptile r3 = new Reptile("snake", "gator", true);
            Reptile r4 = new Reptile("lizard", "iguana");
            r2.print("message from reptile print");
            //2 lines of code
            string answer = r4.getAnimalPhylum();
            Console.WriteLine($"Phylum is {answer}");
            //string interplation
            //1 line of code
            Console.WriteLine($"Type is {r4.getAnimalType()}");
            r4.setAnimalPhylum("snake");
            r4.setAnimalType("corbra");
            Console.WriteLine($"Phylum is {r4.getAnimalPhylum()}");
            Console.WriteLine($"Type is {r4.getAnimalType()}");

            Console.WriteLine($"Will it kill you? {r3.getIsVenomous()}");
            Console.WriteLine($"Will it kill you? {r3.getIsVenomous()}");
            r4.setIsVenomous(true);

        }
    }
}
