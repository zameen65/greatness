﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LabInheritance02
{
   
    class Bird : Animal
    {
        public Bird()
        //:base is OUTSIDE the body of the condtructor
        : base()
        {
            Console.WriteLine("Bird noargs constructor called");
        }
        public Bird(string value) //or  public Bird()
            : base(value)
        {
            Console.WriteLine("Bird string constructor called");
            Console.WriteLine(value);
            //or Console.WriteLine(message from bird print);
        }
        public Bird(string value, string value2) //or  public Bird()
           : base(value, value2)
        {
            Console.WriteLine("Bird string constructor called");
            Console.WriteLine(value);
            //or Console.WriteLine(message from bird print);
        }
    }
}
