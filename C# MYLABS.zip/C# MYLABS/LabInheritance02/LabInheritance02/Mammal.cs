﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LabInheritance02
{
    class Mammal: Animal
    { 
        public  Mammal()
            //:base is OUTSIDE the body of the condtructor
        :base()
        {
            Console.WriteLine("Mamal noargs constructor called");
        }
        public Mammal(string value)
            :base(value)
        {
            Console.WriteLine("Mamal string constructor called");
            Console.WriteLine(value);
        }
        public Mammal(string value, string value2)
            : base(value, value2)
        {
            Console.WriteLine("Mamal string constructor called");
            Console.WriteLine(value);
        }
        public override void print(string message)
            //this method produces a DIFFERENTmessage that is its parent 
        {
            base.print(message);
        }
    }
}
