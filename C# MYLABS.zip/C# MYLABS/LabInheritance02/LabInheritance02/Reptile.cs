﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LabInheritance02
{
    class Reptile : Animal
    {
        bool isVenomus;
        public Reptile()
        //:base is OUTSIDE the body of the condtructor
        : base()
        {
            isVenomus = false;
            Console.WriteLine("Reptile noargs constructor called");
        }
        public Reptile(string value)
            : base(value)
        {
            isVenomus = false;
            Console.WriteLine("Reptile string constructor called");
            Console.WriteLine(value);
        }
        public Reptile(string value, string value2)
           : base(value, value2)
        {
            isVenomus = false;
            Console.WriteLine("Reptile string constructor called");
            Console.WriteLine(value);
        }
        public Reptile(string value, string value2, bool value3)
          : base(value, value2)
        {
            isVenomus = value3;
            Console.WriteLine("Reptile string constructor called");
            Console.WriteLine(value3);
        }
        public override void print(string message)
        {
            base.print(message);
        }
        //put the getter and setters in the class where the field is declared
        public bool getIsVenomous()
        {
            return isVenomus;
        }
        public void setIsVenomous(bool isVenomous)
        {
          this.isVenomus = isVenomous;
        }
    }
}
