﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LabInheritance02
{
    class Animal
    {
        public string AnimalPhylum;
        public string AnimalType;

        public Animal()
        //part 1 uses inheritance
        //contains 2 constructors for each and a print method
       
            {
            Console.WriteLine("Animal noargs constructor called");
            }
        public Animal(string value)
        {
            Console.WriteLine("Animal string constructor called");
            Console.WriteLine(value);
        }
        public Animal(string value, string value2 )
         
        {
                AnimalType = value2;
                AnimalPhylum = value;
        Console.WriteLine("Animal string constructor called");
        Console.WriteLine(value);
        }
    public virtual void print(string message)
        {
            Console.WriteLine(message);
        }
        //getter and setters
        public string getAnimalType()
        {
            return AnimalType;
        }
        public void setAnimalType(string AnimalType)
        {
             this.AnimalType= AnimalType;
        }
        public string getAnimalPhylum()
        {
            return AnimalPhylum;
        }
        public void setAnimalPhylum(string AnimalPhylum)
        {
            this.AnimalPhylum = AnimalPhylum;
        }
    }
}

