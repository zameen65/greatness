﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab12
{
    class Program
    {
        static string output = " ";
        static void Main(string[] args)
        {
            DateTime myBirthday = new DateTime(1996, 8, 12);
            Console.WriteLine(myBirthday.ToString());
            //or
            //DateTime = new DateTime(2015, 7, 23);
            // Console.WriteLine(DateTime)

            DateTime today =  DateTime.Today;
            Console.WriteLine("Today: "+ today);
            Console.WriteLine(today == DateTime.Today);

            Console.WriteLine("Yesterday: " + GetYesterday(today));

            Console.WriteLine("A Year ago today: " + GetOneYear(today));
            Console.Write("Right now it's ");

            Console.WriteLine(DateTime.Now);

            Console.WriteLine("Now and tomorrow: " + DateTime.Now + " and " + Tomorrow(today));

        }   
        // only need a method for this one- didn't write any method just wrote to reinforce
        public static DateTime GetYesterday(DateTime arg1)
        {
            return arg1.AddDays(-1);
           
        }
        //unecassary method
        public static DateTime GetOneYear(DateTime arg1)
        {
            return arg1.AddDays(-365);

        }
        public static DateTime Tomorrow(DateTime arg1)
        {
            return arg1.AddDays(+1);

        }

    }
}
