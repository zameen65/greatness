﻿using System;
namespace DemoBaseConstructorAndMethodCalls
{
    public class Base // This is the base class.
    {
        public Base(string value)
        {
            // Executes some code in the constructor.
            Console.WriteLine("Base constructor (string)");
        }
        public Base()
        {
            // Executes some code in the constructor.
            Console.WriteLine("Base constructor default");
        }
        public virtual void Howdy(string message)
        {
            // Executes some code in the constructor.
            Console.WriteLine("Howdy from Base default");
            Console.WriteLine(message);
        }
    }

    public class Derived : Base // This class derives from the previous class.
    {
        public Derived(string value)
            //call base defalult constructor 
            //use :baseName(methodName)
            : base(value)
        {
            // The base constructor is called first.
            // ... Then this code is executed.
            Console.WriteLine("Derived constructor string");
        }
        public Derived()
               : base()
        {
            // The base constructor is called first.
            // ... Then this code is executed.
           
            Console.WriteLine("Derived constructor default");
        }
        public override void Howdy(string message)
        {
            // Executes some code in the constructor.
            Console.WriteLine("Howdy from Base default");
            //call the Base's Howdy method
            //use baseName.methodName
            base.Howdy(message);
        }
    }

    class Program
    {
        static void Main()
        {
            // Create a new instance of class A, which is the base class.
            // ... Then create an instance of B.
            // ... B executes the base constructor.
            Base a = new Base();
            Base b = new Base("SomeString");
            Derived x = new Derived();
            Derived y = new Derived("SomeString");
            y.Howdy("call to derived howdy");
        }
    }
}