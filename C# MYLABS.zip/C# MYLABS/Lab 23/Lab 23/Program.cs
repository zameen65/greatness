﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab_23
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] testArray = { 4, 7, 4, 2, 7, 3, 7, 8, 3, 9, 1, 9 };
            //define the array but don't initialize it
            //we need this array for index numbers
            int[] maxValIndices;
            int maxVal = Maxima(testArray, out maxValIndices);
            console.WriteLine("");

        }
        static int Maxima()
    }
}
