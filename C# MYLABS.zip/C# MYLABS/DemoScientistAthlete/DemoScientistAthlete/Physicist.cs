﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DemoScientistAthlete
{
    class Physicist : Scientist
    {
        public static int Physicsts
        { get; set; }
        
        public bool isCrazy
        {
            get; set;
        }
        public Physicist()
            //compiler makes silent call to noargs/defalut Constructor /p.259
        {
            Physicsts ++;
        }

        public Physicist(string LastName, string FirstName) 
            : base(LastName, FirstName)
        {
            Physicsts ++;
        }

        public Physicist(string LastName, string FirstName, bool HasNobelPrize) 
            : base(LastName, FirstName, HasNobelPrize)
        {
            this.isCrazy = isCrazy;
            Physicsts++;
        }
        public override string talk(string message)
        {
            base.talk("call Scientist");
            Console.WriteLine("Physicst");
            return message;
        }
    }
}
