﻿



using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DemoScientistAthlete
{
    class Program
    {
        static void Main(string[] args)
        {
            try { doWork();  }

            catch (Exception Ex)
            {
                Console.WriteLine(Ex.Message);
            }

            finally
            {
                Console.WriteLine("Everything is Ok");
            }
        }
            static void doWork()
            {
                Physicist p1 = new Physicist();
                Console.WriteLine(p1.FirstName);
            //calls set of all 3 Properties by context
            p1.LastName="Ameen";
            p1.FirstName="Zaki";
            p1.HasNoblePrize=true;
            Console.WriteLine(p1.FirstName);
            Console.WriteLine(p1.LastName);
            Console.WriteLine(p1.HasNoblePrize);
            Console.WriteLine();



            Physicist p2 = new Physicist("Einsteain", "Albert", true);
            //calls get of all & Properties by context
            Console.WriteLine(p2.FirstName);
            Console.WriteLine(p2.LastName);
            Console.WriteLine(p2.HasNoblePrize);
            Console.WriteLine();


            Physicist p3 = new Physicist("Cooper", "Sheldon");
            Console.WriteLine(p3.FirstName);
            Console.WriteLine(p3.LastName);
            Console.WriteLine(p3.HasNoblePrize);
            Console.WriteLine();

            Basketball bb1 = new Basketball();
            bb1.FirstName = "Micheal";
            bb1.LastName = "B.Jorodan";
            bb1.HasRing = true;
            Console.WriteLine(bb1.FirstName);
            Console.WriteLine(bb1.LastName);
            Console.WriteLine(bb1.HasRing);

            Console.WriteLine($"Number of persons {Person.Persons}");
            Console.WriteLine($"Number of Athlete {Athlete.Athletes}");
            Console.WriteLine($"Number of Hoopers {Basketball.Hoopers}");

            //have to static to scientist to it this way or you could do like line 30-64
            Console.WriteLine($"Number of Scientist {Scientist.Scientists}");
            Console.WriteLine($"Number of Physicist {Physicist.Physicsts}");
            Console.WriteLine(p1.talk("the cat is both dead and alive"));

            //GetType displays: namespace.Classname
            Console.WriteLine(p1.GetType());
            //see DeomLab42 for more detail
            if (p1 is Person) 
            { Console.WriteLine("p1 is a Perosn"); }
            else
            { Console.WriteLine("p1 is Not a Person"); }
            /*  if (p1 is Athlete)
              { Console.WriteLine("p1 is a Perosn"); }
              else
              { Console.WriteLine("p1 is Not a Person"); }
              */

            Person temp = p1 as Person;
            //as tests for successful casting after
            if (temp != null)
                Console.WriteLine("p1 ISA Person.");
            else
                Console.WriteLine("p1 is NOT a Person.");
                

        }

    }

}
