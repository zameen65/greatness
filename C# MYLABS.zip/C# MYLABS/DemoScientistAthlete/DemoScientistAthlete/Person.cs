﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DemoScientistAthlete
{
    //abstract tells you can inherirt but not instanciate
    abstract class Person :ITalk
    {
        //proerty
        public static int Persons 
            {
            get; set;
            }
            //need access modifer PUBLIC for property
        public string FirstName
        { get; set; }

        //proerty
        public string LastName
        { get; set; }
        //protectd 
        protected Person()
        {
            Persons++;
        }
        protected Person(string LastName, string FirstName)
        {
            this.LastName = LastName;
            this.FirstName = FirstName;
            Persons++;
        }

        //string ITalk.talk(string message)
          virtual public string talk(string message)  
        {
            Console.WriteLine("Person");
            return message;

        }
    }
}
