﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DemoScientistAthlete
{
    class Scientist : Person
    {
        public static int Scientists
        { get; set; }

        public bool HasNoblePrize
        { get; set; }

        protected Scientist()
            //explict call to parent's no args
            : base()
        {
            Scientists++;
        }

        protected Scientist(string LastName, string FirstName) 
            //lastName & FirstNAme live in Person
            //: base is outside of the constructor of the body
            : base(LastName, FirstName)
        {
            Scientists++;
        }

        protected Scientist(string LastName, string FirstName, bool HasNobelPrize)
           : base(LastName, FirstName)
        {
            this.HasNoblePrize = HasNoblePrize;
        }
       public override  string talk(string message)
        {
            //base.method() is always in the body
            base.talk("call Person");
            Console.WriteLine("Scientist");
            return message;
        }
    }
}
