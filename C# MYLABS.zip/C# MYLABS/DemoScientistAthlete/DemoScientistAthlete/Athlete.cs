﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DemoScientistAthlete
{
    class Athlete : Person
    {
        public static int Athletes
        {
            get;set;
        }
        public bool HasRing
        {
            get; set;
        }
        protected Athlete()
        {
            Athletes ++;
        }

        protected Athlete(string LastName, string FirstName) 
            : base(LastName, FirstName)
        {
            Athletes ++;

        }
        public override string talk(string message)
        {
            return message;
        }
    }
}
