﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DemoScientistAthlete
{
    class Basketball : Athlete
    {
        public static int Hoopers
        {
            get;set;
        }
        public Basketball()
        {
            Hoopers++;
        }

        public Basketball(string LastName, string FirstName) 
            : base(LastName, FirstName)
        {
            Hoopers++;

        }
    }
}
