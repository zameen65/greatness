using System;
using MidTerm;
//using MidTerm.BozoNationalBank;
//using MidTerm.StoogeAmalgamatedBank;

namespace MidTerm
{
   class MainEntryPoint
   {
      static void Main()
      {
         IBankAccount BozoAccount = new SaverAccount();
         IBankAccount StoogeAccount = new GoldAccount();
         // SaverAccount BozoAccount = new SaverAccount();
         // GoldAccount StoogeAccount = new GoldAccount();
         //BozoAccount.PayIn(200);
         //BozoAccount.Withdraw(300);  
         try
         {
             //good withdrawals
             BozoAccount.Deposit(200);
             BozoAccount.Withdraw(100);             
             StoogeAccount.Deposit(500);
             StoogeAccount.Withdraw(400);             
             //bad withdrawals             
             BozoAccount.Withdraw(200);             ;
             StoogeAccount.Withdraw(200);
             
         }
           
            catch (InsufficientFundsException excp)
         {
             
             Console.WriteLine(excp.Message);
         }
            catch (Exception excp)
            {

                Console.WriteLine(excp.Message);
            }

            finally
         {
                Console.WriteLine(StoogeAccount.ToString());
                Console.WriteLine(BozoAccount.ToString());
         }
      }
   }
}







