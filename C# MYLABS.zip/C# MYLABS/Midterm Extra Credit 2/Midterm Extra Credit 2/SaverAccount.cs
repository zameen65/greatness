﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Midterm;

namespace Bozo
{
    class SaverAccount: IBankAccount
    {
        public double Balance
        { get; set; }
        public virtual void deposit(double dep)
        {
            Balance = Balance + dep;
        }
        public virtual bool withdraw(double wth)
        {
            if (wth > Balance)

            {
               
                Console.WriteLine("Withdraw Failed");
                 return false;
            }

            else
            {
                Balance = Balance - wth;
                return true;
            }
        }
    }
}
