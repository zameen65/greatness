﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab8
{
    class Program
    {
        static void Main(string[] args)
        {
            //could have done double Fred;Operator;operand1;operand2 
            double Fred = 0.00;
             
            //first line prompt;
            Console.WriteLine("This program allows you to perform an operation on two numbers");


            //Enter number and Read 
              Console.WriteLine("To proceed, enter a number");
               double operand1=double.Parse(Console.ReadLine());
            
            //Enter operator and Read 
            Console.WriteLine("To proceed, enter a operator");
           int Operator = char.Parse(Console.ReadLine());

            //Enter number and Read 
            Console.WriteLine("To proceed, enter a number");
          double operand2 = double.Parse(Console.ReadLine());

            if (Operator == '+' || Operator == '-' || Operator == '*' || Operator == '/') 
            {
                Console.WriteLine("Operation Ok - if");
            }
            else
            {
                Console.WriteLine("Operation bad - if");
            }

            switch (Operator)
            {
                case '+':
                    Fred = operand1 + operand2;
                  
                    break;
                case '-':
                    Fred = operand1 - operand2;
                    
                    break;
                case '*':
                    Fred = operand1 * operand2;
                    
                    break;
                case '/':
                    Fred = operand1 / operand2;
                    
                    break;

                default:
                    Console.WriteLine("Bad operation - switch");
                    break;

                    
                    
            }

            Console.WriteLine($"{operand1} {Operator} {operand2}= {Fred}");






        }
    }
}
