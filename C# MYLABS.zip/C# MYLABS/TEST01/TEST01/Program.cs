﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TEST01
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World"); //console is the class, write line is the system(maybe)
            int age = 42;
            Console.WriteLine(age);
    ;
        }
    }
}
