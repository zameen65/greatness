﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab20
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] myArray = { 1, 8, 3, 42, 6, 2, 5, 9, 10, 3, 0, 2 };
            int maxNbr = MaxValue(myArray);
            Console.WriteLine("The maximum value in myArray is {0}", maxNbr);

        }
    }
}
