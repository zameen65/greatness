﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab18
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Here are 3 of my freinds:");
            Console.WriteLine("For Loop:");
            string []freindNames ={ "Zaki", "Taki", "Blake" };
           

            for (int i=0; i<freindNames.Length; i++)
            {
                string name = freindNames[i];
                Console.WriteLine(name);
            }

            Console.WriteLine("For each Loop:");
            
            foreach(string friendNames in freindNames)
            {
                Console.WriteLine(friendNames);
            }
            

        }
    }
}
