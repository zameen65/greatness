﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DemoTriangles
{
    //lab3b-do over
    class Program
    {
        static void Main(string[] args)
        {
            Triangle T1 = new Triangle();
            //each triangle must be referenced by its instanced name
            //create 3 fields representing each of the 3 sides of a triangle (use encapsulation)
            //Console.WriteLine($"{T1.side1} {T1.side2} {T1.side3}");
            Console.WriteLine($"{T1.getSide1()} {T1.getSide2()} {T1.getSide3()}");
            T1.setSide1(2);
            T1.setSide2(2);
            T1.setSide3(2);
            //verify that the setters worked
            //Create 4 constructors - the first is the default or noargs constructor and it initializes the 3 fields to 1, 
            //the second initializes the first side to the value you pass to the constructor and the other 2 sides to 1, 
            //the third initializes the first two sides to values you pass to the constructor and the third side to 1, 
            //the fourth initializes all three sides to values that you pass to the constructor. 
            Console.WriteLine($"{T1.getSide1()} {T1.getSide2()} {T1.getSide3()}");

            Triangle T2 = new Triangle(4);
            Console.WriteLine($"{T2.getSide1()} {T2.getSide2()} {T2.getSide3()}");

            Triangle T3 = new Triangle(4, 6.15);
            Console.WriteLine($"{T3.getSide1()} {T3.getSide2()} {T3.getSide3()}");

            Triangle T4 = new Triangle(4, 6.15, 9.3333);
            Console.WriteLine($"{T4.getSide1()} {T4.getSide2()} {T4.getSide3()}");
        }
    }
}
