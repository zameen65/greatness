﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DemoTriangles
{
    class Triangle
    {
        //use  private insure encapsulation
        private double side1, side2, side3;
        
        //4 constructurs total

        //no args. 3 defaluts
        public Triangle()
        {  //the first is the default or noargs constructor and it initializes the 3 fields to 1,
            side1 = side2 = side3 = 1;
        }
        //overload 1-2 defaluts
        public Triangle(double side1)
        {  
            side2 = side3 = 1;
            this.side1 = side1;
        }
        //overload 2-1 defaluts
        public Triangle(double side1, double side2)
        {
            side3 = 1;
            this.side1 = side1;
            this.side2 = side2;
        }
        //overload 3-1 defaluts
        public Triangle(double side1, double side2, double side3)
        {
            this.side3 = side3;
            this.side1 = side1;
            this.side2 = side2;
        }

        //getters / accessors are public
        public double getSide1()
        {
            return side1;
        }
        public double getSide2()
        {
            return side2;
        }
        public double getSide3()
        {
            return side3;
        }
        //setters /mutators general take arg. but return nothing
        public void setSide1(double side1)
        {
            this.side1 = side1;
        }
        public void setSide2(double side2)
        {
            this.side2 = side2;
        }
        public void setSide3(double side3)
        {
            this.side3 = side3;
        }
        
       
    }
}
