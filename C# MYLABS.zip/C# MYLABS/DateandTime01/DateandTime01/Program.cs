﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DateandTime01
{ 
    class Program
/*
 
 DateTime Structure
 https://msdn.microsoft.com/en-us/library/system.datetime%28v=vs.100%29.aspx
 */
{
    static string output = " ";
    static void Main(string[] args)
    {
        /*
         Custom DateTime Formatting
         * 
         This example shows how to format DateTime using String.Format method.
         This may also be accomplished by using the DateTime.ToString method.

         There are following custom format specifiers y (year), M (month), d (day),
         h (hour 12), H (hour 24), m (minute), s (second),
         f (second fraction), F (second fraction, trailing zeroes are trimmed), 
         t (P.M or A.M) and z (time zone).
         */

        //DateTime dt = new DateTime(2015, 10, 15, 16, 5, 7, 123);
        DateTime dt = new DateTime();
        output = String.Format("{0:y yy yyy yyyy}", dt);
        Console.WriteLine(output);
        output = String.Format("{0:M MM MMM MMMM}", dt);
        Console.WriteLine(output);
        output = String.Format("{0:d dd ddd dddd}", dt);
        Console.WriteLine(output);
        output = String.Format("{0:h hh H HH}", dt);
        Console.WriteLine(output);
        output = String.Format("{0:m mm}", dt);
        Console.WriteLine(output);
        output = String.Format("{0:s ss}", dt);
        Console.WriteLine(output);
        output = String.Format("{0:f ff fff ffff}", dt);
        Console.WriteLine(output);
        output = String.Format("{0:F FF FFF FFFF}", dt);
        Console.WriteLine(output);
        output = String.Format("{0:t tt}", dt);
        Console.WriteLine(output);
        output = String.Format("{0:z zz zzz}", dt);
        /*
         You can use also date separator / (slash) and time sepatator : (colon). 
         These characters will be rewritten to characters defined in the current 
         DateTimeForma­tInfo.DateSepa­rator and DateTimeForma­tInfo.TimeSepa­rator.
         */

        output = String.Format("{0:M/d/yyyy HH:mm:ss}", dt); // English - USA
        Console.WriteLine(output);
        output = String.Format("{0:d.M.yyyy HH:mm:ss}", dt); // Deutsch
        Console.WriteLine(output);

        /*
         see;  https://msdn.microsoft.com/en-us/library/system.globalization%28v=vs.100%29.aspx
         */
        DateTime classDate = new DateTime(2017, 8, 22, 1, 2, 3, 4);

        output = "Today is: " + String.Format("{0:M/d/yyyy HH:mm:ss:ffff}", classDate);
        Console.WriteLine(output);
        output = "Tomorrow will be: " + String.Format("{0:M/d/yyyy HH:mm:ss:ffff}", classDate.AddDays(1));
        Console.WriteLine(output);
        output = "Yesterday was: " + String.Format("{0:M/d/yyyy HH:mm:ss:ffff}", classDate.AddDays(-1));
        Console.WriteLine(output);
        // use some Properties
        output = "Today is: " + String.Format("{0:M/d/yyyy HH:mm:ss:ffff}", DateTime.Today);
        Console.WriteLine(output);
        output = "It is: " + String.Format("{0:M/d/yyyy HH:mm:ss:ffff}", DateTime.Now);
        Console.WriteLine(output);
        output = "UTC is: " + String.Format("{0:M/d/yyyy HH:mm:ss:ffff}", DateTime.UtcNow);
        Console.WriteLine(output);
        //use a TimeSpan
        output = "TimeSpan is: " + classDate.TimeOfDay.ToString();
        Console.WriteLine(output);
        //use an enum
        output = "Day of week is: " + classDate.DayOfWeek.ToString();
        Console.WriteLine(output);
        //use an enum
        output = "Kind is: " + classDate.Kind.ToString();
        Console.WriteLine(output);
        output = "Day of year is: " + classDate.DayOfYear.ToString();
        Console.WriteLine(output);
        output = "Is it a leap year? " + DateTime.DaysInMonth(2001, 2).ToString();
        Console.WriteLine(output);
        output = "Is it a leap year? ";
        Console.Write(output);

        // see: https://msdn.microsoft.com/en-us/library/ty67wk28%28v=vs.100%29.aspx
        // for a discussion of the ?: operator
        Console.WriteLine(DateTime.DaysInMonth(2001, 2).ToString() == "28" ? "Nope!" : "Yup!");

        DateTime thisDate1 = new DateTime(2011, 6, 10);

        Console.WriteLine("Instance is " + thisDate1.ToString("MMMM dd, yyyy") + ".");
        Console.WriteLine("Instance is " + thisDate1.ToString("MM/dd/yyyy") + ".");

        DateTimeOffset thisDate2 = new DateTimeOffset(2011, 6, 10, 15, 24, 16,
                                                      TimeSpan.Zero);
        Console.WriteLine("The current date and time: {0:MM/dd/yy H:mm:ss zzz}",
                           thisDate2);
        //see https://msdn.microsoft.com/en-us/library/Aa691085%28v=VS.71%29.aspx
        //for numeric literal suffixes

    }
}
}