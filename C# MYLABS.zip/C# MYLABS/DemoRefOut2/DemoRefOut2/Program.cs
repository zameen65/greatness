﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DemoRefOut2
{
    class Program
    {
        static void Main(string[] args)
        {
            int i = 1;
            int j = 6;
            //invocation of refMethod()
            //i is a ref, it will be changed
            //j is passed by value, it won't change
            refMethod(ref i, j);
            Console.WriteLine($"from call {i}");
            Console.WriteLine($"from call {j}");
        }
        public static void refMethod(ref int arg, int arg2)
        {
            arg++;
            arg2 = 42;
            Console.WriteLine($"from method {arg}");
            Console.WriteLine($"from method {arg2}");
        }
    }
   
}
