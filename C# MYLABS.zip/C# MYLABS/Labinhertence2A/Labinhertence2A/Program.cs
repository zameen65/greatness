﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Labinhertence2A
{
 
    class Program
    {
        static void Main(string[] args)
        {
            //instaniate animals with all constructors
            // define name and pointer on stack
            Animal animal1;
            //create the instance on the heap
            animal1 = new Animal();
            // do both in 1 line of code
            Animal animal2 = new Animal("I'm an animal");

            //print is NOT static
            animal2.print();

            Mammal Mammal1 = new Mammal();
            Mammal Mammal2 = new Mammal("I'm a human");
            Mammal Mammal3 = new Mammal("mammal", "human");
            Mammal2.print();

            Bird Bird1 = new Bird();
            Bird Bird2 = new Bird("I'm a parrot");
            Bird Bird3 = new Bird("bird", "parrot");
            Bird2.print();

            Reptile reptile1 = new Reptile();
            Reptile Reptile2 = new Reptile("I'm a viper");
            Reptile Reptile3 = new Reptile("snake", "viper", true);
            Reptile Reptile4 = new Reptile("lizard", "iguana");

            Reptile2.print();
            //2 lines of code
            string answer = Reptile4.getAnimalPhylum();
            Console.WriteLine($"Phylum is {answer}");
            //1 line of code
            Console.WriteLine($"Type is {Reptile4.getAnimalType()}");
            Reptile4.setAnimalPhylum("snake");
            Reptile4.setAnimalType("cobra");
            Console.WriteLine($"Phylum is {Reptile4.getAnimalPhylum()}");
            Console.WriteLine($"Type is {Reptile4.getAnimalType()}");

            Console.WriteLine($"Will it kill you? {Reptile3.getIsVenomous()}");
            Console.WriteLine($"Will it kill you? {Reptile4.getIsVenomous()}");
            Reptile4.setIsVenomous(true);
            Console.WriteLine($"Will it kill you? {Reptile4.getIsVenomous()}");

            //Console.WriteLine(Reptile4.isVenomous);
            Console.WriteLine(Reptile4.getIsVenomous());
        }
    }
}
