﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab_2
{
    class Program
    {
        static void Main(string[] args)
        {
            double balance, interestRate, targetBalance;
            double fbalance, finterestRate, ftargetBalance;
            double dbalance, dinterestRate, dtargetBalance;

            Console.WriteLine("What is your current balance");
            balance = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("What is your annual interst rate(in %)?");
            interestRate = 1 + (Convert.ToDouble(Console.ReadLine()));
            Console.WriteLine("What is your desired balance");

            targetBalance = Convert.ToDouble(Console.ReadLine());
            dbalance = fbalance = balance;
            dinterestRate = finterestRate = interestRate;
            dtargetBalance = ftargetBalance = targetBalance;

            int totalYears = 0;

            Console.WriteLine("START WHILE LOOP");
            while (balance < targetBalance)
            {
                balance *= interestRate;
                totalYears++;
            }
            Console.WriteLine("END WHILE LOOP");




            Console.WriteLine("START FOR LOOP");
            totalYears = 0; //can use i
            for (int i = 0; fbalance < ftargetBalance; i++)

            {
                fbalance *= finterestRate;

                totalYears++;
                //Console.WriteLine(balance) - coverts to string
            }
        }
    }
}

