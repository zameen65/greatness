﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp4
{
    class Triangle
    {
        private double side1;
        private double side2;
        private double side3;



        public Triangle(double side1, double side2, double side3)
        {
            this.side1 = side1;
            this.side2 = side2;
            this.side3 = side3;
            Console.WriteLine("Triangle with 0 default sides");

        }
        public Triangle()
        {

        }

    public double getSide1()
    {
        return side1;
    }
    public double getSide2()
        {
            return side2;
        }
    public double getSide3()
     {
         return side3;
     }
        public void setSide1(double side1)
    {
        this.setSide1 = side1;
    }
    }
}    