﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp4
{
    class Program
    {
        static void Main(string[] args)
        {
            Triangle T4 = new Triangle(10.0, 20.0, 30.0);
            Console.WriteLine("fourth triangle side1 =: {0} ", T1.getSide()));
            Console.WriteLine("fourth triangle side1 =: {0} ", T2.getSide()));
            Console.WriteLine("fourth triangle side1 =: {0} ", T3.getSide()));
            Console.WriteLine("fourth triangle side1 =: {0} ", T4.getSide()));

            T4.setSide1(6.0);

            Console.WriteLine("fourth triangle side3 -")
        }
    }
}
