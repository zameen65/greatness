﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab_200
{
    class Program
    {
        static void Main(string[] args)
        {
            //prompt user for input
            Console.WriteLine("Enter your first name in lower case");
            //capture response
            string firstName= "zaki";
            Console.WriteLine(firstName);
            string Name2;
            refMethod(ref firstName);
            outMethod(out Name2);
            
          
          
            
        }
        public static void refMethod(ref string arg1)
        {
            arg1=arg1.ToUpper();
            int length = arg1.Length;
            Console.WriteLine(arg1);
            Console.WriteLine(length);
        }
        public static void outMethod(out string Name2)
        {
            Console.WriteLine("I'm going to give you a new first name");
            Name2 = "Your new first name is Ameen";
            Console.WriteLine(Name2);
        }
    }

}
