﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab_17A
{
    
        enum orientation : byte
        //use byte instead the defalut (int)

        {
            //realtive is to 1 NOT o
            north = 1,
            south = 2,
            east = 3,
            west = 4
        }
    
}
