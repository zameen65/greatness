﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab_17A
{
    class Program
    {
        static void Main(string[] args)
        {
            route myRoute;
            //int mtDirection =0;
            byte myDirection = 0;
            double myDistnace;
            Console.WriteLine("1)North \n 2)South \n3) East \n4) West");
            Console.WriteLine("Select a direction:");

            myDirection = Convert.ToByte(Console.ReadLine());
            Console.WriteLine("Input a Distance:");
            myDistnace = Convert.ToDouble(Console.ReadLine());


            //explicit cast
            myRoute.direction = (orientation)myDirection;


            myRoute.distance = myDistnace;
            Console.WriteLine("myRoute specifies a direction of {0} and a" + "distance of {1}", myRoute.direction, myRoute.distance);
        }
    }
}
