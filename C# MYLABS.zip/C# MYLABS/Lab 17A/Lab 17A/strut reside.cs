﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab_17A
{
    
    
        struct route
        {
            public orientation direction;
            public double distance;
        }
    
}
