﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassDemo
{
    class Program
    {
        private int age;
        private string firstName;
        private string lastName;
        private string address;
        private string city;
        private string state;
        private string zip;

        public static int population;


        //we want a constructor that takes these args
        
        public Program(string firstname, string lastname, int age)
        {
            firstName = firstname;
            lastName = firstname;
            this.age = age; //put this cause it was confused
            population++;
        }

        //but we lose the default / noargs constructor so we have to manually code it
        public Program()
        {

        }
        //Encapsulation
        //accesor/getter method
        //methond name get 
        //we want to see the current value of firstname
        //getters generally dont take an arg but do return a value

        //accessor / getter method
        public string getFirstName()
        {
            return firstName;
        }
       
        //change void firstjake

        public void setFirstName(string firstname)
        {
            firstName = firstname;
        } 
        //now we need getters and setter for the other feilds

            public int getAge()
        {
            return age;
        }

        //mutator / setter method
        public void set (int age)
        {
            this.age = age;
        }
        //now we need getters & setters for the other fields
    }
}
}
