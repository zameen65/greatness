﻿using System;
using MidTerm;
//using MidTerm.BozoNationalBank;
//using MidTerm.StoogeAmalgamatedBank;


namespace MidTerm.StoogeAmalgamatedBank
{
    public class GoldAccount : IBankAccount
    {
        public static int numberOfGolds;
        private decimal balance;
        public void Deposit(decimal amount)
        {
            balance += amount;
        }
        public bool Withdraw(decimal amount)
        {
            
            if (balance >= amount)
            {
                balance -= amount;
               // return true;
            }
            //Console.WriteLine("Withdrawal attempt failed.");
            //return false;
            Console.WriteLine("Throwing InsufficientFundsException on. " + this.GetType().ToString());
            throw new InsufficientFundsException("Withdrawal attempt failed. Make a deposit first");
            
        }
        public decimal Balance
        {
            get
            {
                return balance;
            }
        }
        public override string ToString()
        {
            return String.Format("Stooge Bank Saver: Balance = {0,6:C}", balance);
        }

        public GoldAccount()
        {
            numberOfGolds++;
        }

        ~GoldAccount()
        {
            numberOfGolds--;
           

            Console.WriteLine("Number of GoldAccounts after destructor = "
                      + Convert.ToString(GoldAccount.numberOfGolds));
        }
    }

}