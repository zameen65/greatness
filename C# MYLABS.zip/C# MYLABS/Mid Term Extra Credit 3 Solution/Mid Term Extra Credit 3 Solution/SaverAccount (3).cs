﻿using System;
using MidTerm;
//using MidTerm.BozoNationalBank;
//using MidTerm.StoogeAmalgamatedBank;

namespace MidTerm.BozoNationalBank
{

    public class SaverAccount : IBankAccount
    {
        public static int numberOfSavers = 0;
        private decimal balance;
        public void Deposit(decimal amount)
        {
            balance += amount;
        }
        public bool Withdraw(decimal amount)
        {
            if (balance >= amount)
            {
                balance -= amount;
                return true;
            }
            Console.WriteLine("Throwing InsufficientFundsException on. " + this.GetType().ToString());
            throw new InsufficientFundsException("Withdrawal attempt failed. Make a deposit first");
        }
        public decimal Balance
        {
            get
            {
                return balance;
            }
        }
        public override string ToString()
        {
            return String.Format("Bozo Bank Saver: Balance = {0,6:C}", balance);
        }

        public SaverAccount()
        {
            numberOfSavers++;
        }
        ~SaverAccount()
        {
            numberOfSavers--;
           Console.WriteLine("Number of SaverAccounts = "
              + Convert.ToString(SaverAccount.numberOfSavers));

            
        }
    }
}
