﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DemoStringInterpolation
{
    class Program
    {
        private static string name = "Moe";

        static void Main(string[] args)
        {
            //Brute force
            Console.WriteLine("Moe is one of the 3 Stooges");
            //Concatenation
            Console.WriteLine("Moe " + "is " + "one " + "of the " + "3 Stooges");
            //Composite format string
            Console.WriteLine("{0} is one of the 3 Stooges", name);
            // string interpolation p.46, new in C# 6.0
            //uses variables as placeholders rather than relative position {0}
            Console.WriteLine($"{name} is one of the 3 Stooges");

        }
    }
}
