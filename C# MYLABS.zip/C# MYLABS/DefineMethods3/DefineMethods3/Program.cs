﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DefineMethods3
{
class Program
        {
            static void Main()
            {
                // standard calling syntax.
                methodWithOptParms(1, "Moe");

                // Omit the optional parameters.
                methodWithOptParms();

                // Omit second optional parameter.
                methodWithOptParms(1);

                // You can't omit the first but keep the second.
                //Method("Moe");        

                // Specify one named parameter.
                methodWithOptParms(stooge: "Curly");

                // Specify both named parameters.
                methodWithOptParms(value: 2, stooge: "larry");
                methodWithOptParms(stooge: "larry", value: 2);
            }

            static void methodWithOptParms(int value = 1, string stooge = "Moe")
            {
                // see p. 248
                Console.WriteLine("value = {0}, name = {1}", value, stooge);
            }
        }
    }
   
