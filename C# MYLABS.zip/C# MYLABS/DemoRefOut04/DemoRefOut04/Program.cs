﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DemoRefOut04
{
    class Program
    {
        static void Main(string[] args)
        {
            //out does not require initialization
            string first;
            string second = "this is the question";
            outMethod(out first, second);
            Console.WriteLine("from call");
            Console.WriteLine(first);  
            Console.WriteLine(second);

        }
        public static void outMethod(out string arg1, string arg2)
        {
            arg1 = "This is the answer";
            arg2 = "this is the answer";
            Console.WriteLine(arg1);
            Console.WriteLine(arg2);

        }
    }
}
