using System;
using MidTerm;
//using MidTerm.BozoNationalBank;
//using MidTerm.StoogeAmalgamatedBank;

namespace MidTerm
{
   class MainEntryPoint
   {
      static void Main()
      {
         Console.WriteLine("Using interfaces");
         IBankAccount BozoAccount = new SaverAccount();
         IBankAccount StoogeAccount = new GoldAccount();
         
            // see http://msdn.microsoft.com/en-us/library/364x0z75.aspx
            // for decimal type

         Console.WriteLine("Using classess");
         BozoAccount.Deposit(200000.15m);
         BozoAccount.Withdraw(100.75M);
         Console.WriteLine(BozoAccount.ToString());
         StoogeAccount.Deposit(500.37m);
         StoogeAccount.Withdraw(600.22M);
         StoogeAccount.Withdraw(100);

            Console.WriteLine("Using classes");
            SaverAccount BozoAccount1 = new SaverAccount();
            GoldAccount StoogeAccount1 = new GoldAccount();
            BozoAccount1.Deposit(200000.15m);
            BozoAccount1.Withdraw(100.75M);
            Console.WriteLine(BozoAccount1.ToString());
            StoogeAccount1.Deposit(500.37m);
            StoogeAccount1.Withdraw(600.22M);
            StoogeAccount1.Withdraw(100);
            Console.WriteLine(StoogeAccount1.ToString());
        }
   }
}







