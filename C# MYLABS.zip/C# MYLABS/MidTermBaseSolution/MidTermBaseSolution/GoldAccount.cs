﻿using System;
using MidTerm;
//using MidTerm.BozoNationalBank;
//using MidTerm.StoogeAmalgamatedBank;


namespace MidTerm
{
    public class GoldAccount : IBankAccount
    {   // both the commented code with the private field "balance" and the current code with
        // Balance property with automatic get and set accessors are equivalent
        //private decimal balance;
        public void Deposit(decimal amount)
        {
            //balance += amount;
            Balance += amount;
        }
        public bool Withdraw(decimal amount)
        {
            if (Balance >= amount)
                //if (Balance >= amount)
            {
                //balance= balance + amount
                //incremetn balance
                Balance -= amount;
                return true;
            }
            else
            {
                Console.WriteLine("Withdrawal attempt failed.");
                return false;
            }
        }
        public decimal Balance
        {
            get; set;
            
        }
        public override string ToString()
        {
            //see http://msdn.microsoft.com/en-us/library/dwhawy9k%28v=vs.100%29.aspx#CFormatString
            //for info on String.Format
            return String.Format("Stooge Bank Gold: Balance = {0,6:C}", Balance);
        }
    }

}