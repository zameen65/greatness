﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LabInheritance01
{
    class grandchild :child
    {
        public grandchild()
           : base()
        {
            Console.WriteLine("successfully created by grandchildchild noargs");

        }
        //could have named value-anything
        public grandchild(string value)
            : base(value)
        {
            Console.WriteLine("GrandChild String Constructor.");
        }
        public override void print(string message)
        {
            Console.WriteLine(message);
        }
    }
}
