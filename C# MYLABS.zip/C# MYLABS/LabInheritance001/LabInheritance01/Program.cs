﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LabInheritance01
{
      class Program
    {   
        static void Main(string[] args)
        { 
            //call method from type parent
            //test Parent members- constructors, methods, Fields
            Parent I1 = new Parent();
            Parent I2 = new Parent("SomeString");
            I1.print("Hi from the Print parent with noarg");

            child c1 = new child();
            child c2 = new child("child argument");
            //print is NOT static therefore we need  an instance name rather then a calss.
            c1.print("Hi from the Print child with no arg");
            c2.print("Hi from child with strings arg");

            grandchild d1 = new grandchild();
            grandchild d2 = new grandchild("statement");
            d2.print("Hi from the Print grandchild with no arg");

            greatgrandchild e1 = new greatgrandchild();
            greatgrandchild e2 = new greatgrandchild("statement");
            e2.print("Hi from the Print greatgrandchild with noarg");

        }
    }
}
