﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LabInheritance01
{
    class Parent
    {
        public Parent()
        {
            Console.WriteLine("Parent Default Constructor.");
        }


        public Parent(string value)
        {
            Console.WriteLine("Parent String Constructor.");
        }
        //virtual allows the childrent to overide
        public virtual void print(string message)
        {
            Console.WriteLine(message);
        }
    }
}

