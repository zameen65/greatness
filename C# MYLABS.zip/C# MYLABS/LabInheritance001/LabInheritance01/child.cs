﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LabInheritance01
{
   class child :Parent
    {
        public child()
            :base()
        {
            Console.WriteLine("successfully created by child noargs");
            
        }
        //could have named value-anything
        public child(string value)
            :base(value)
        {
            Console.WriteLine("Child String Constructor.");
        }
        public override  void print(string message)
        {
            Console.WriteLine(message);
        }
    }
}
