﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DemoWageEmployee
{
    class WageEmployee
    {
        //fields are Private to support encapsulation
        //they may be accessed only by public methods of this class
        private string firstname, lastname;
       private int empID;
        private double rate, hours;

        public static int population;
        
        //defalut of no args constructor

        public WageEmployee()
        {
            //must incerment the feild in EVERY constructor
            population++;
        }
        public WageEmployee(string lastname, string firstname, int empID, double rate, double hours)
        {
            //put (.)this to make parameter last name appear
            this.lastname = lastname;
            this.firstname = firstname;
            this.empID=empID;
            this.rate = rate;
            this.hours = hours;
            population++;
        } 
        //string tells you it returning a string
        //getter or accesor methods
         public string getLastName()
        {
            return lastname;
        }
        public string getFirstName()
        {
            return firstname;
        }
        public int getempID()
        {
            return empID;
        }
        public double getRate()
        {
            return rate;
        }
        public double getHours()
        {
            return hours;
        }
        //get all employee info
        public void getWageEmployeeInfo()
        {
            Console.WriteLine(getempID());
            Console.WriteLine(getLastName());
            Console.WriteLine(getFirstName());
            Console.WriteLine(getRate());
            Console.WriteLine(getHours());
        }
        //setter/mutator methods
        public void setLastName(string lastname)
        {
            this.lastname = lastname;
        }
        public void setFirtName(string firstname)
        {
            this.firstname = firstname;
        }
        public void setRate(double rate)
        {
            this.rate = rate;
        }
        public void setHours(double hours)
        {
            this.hours = hours;
        }
        public void setEmpID(int empID)
        {
            this.empID = empID;
        }
        public double calcPay()
        {
            return hours * rate;
        }
        public double calcPayRound()
        {
            return Math.Round(hours * rate, 2); 
        }
    }
}
