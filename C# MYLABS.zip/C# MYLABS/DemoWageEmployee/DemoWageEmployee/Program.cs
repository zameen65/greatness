﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DemoWageEmployee
{
    class Program
    {
        static void Main(string[] args)
        {
            //instantiate an emoloyee
            //invoke  the noargs cconstrutor of WageEmolyee
           
            //defalut of no args constructor
         WageEmployee emp1 = new WageEmployee();
            /*
        Console.WriteLine(emp1.empID);
        Console.WriteLine(emp1.lastname);
        Console.WriteLine(emp1.firstname);
        Console.WriteLine(emp1.rate);
        Console.WriteLine(emp1.hours);
        */
            emp1.getWageEmployeeInfo();
            //instatiate with constructo that takes 5 argumrnts
            WageEmployee emp2 = new WageEmployee("Ameen", "Zaki", 1, 100, 10 );emp2.getWageEmployeeInfo();

            WageEmployee emp3 = new WageEmployee("Ameen", "Zaki", 1, 100, 10); emp3.getWageEmployeeInfo();

            WageEmployee emp4 = new WageEmployee("Ameen", "Zaki", 4, 100.16635, 10); emp4.getWageEmployeeInfo();
            //string interprelation
            Console.WriteLine($"Gross Pay is {emp4.getWageEmployeeInfo()}");

            //
            Console.WriteLine($"Gross Pay is {Math.Round(emp4.calc(),2)}");

            Console.WriteLine($"Gross Pay is {Math.Round(emp4.calc())}");

            /*
            Console.WriteLine(emp2.getempID());
            Console.WriteLine(emp2.getLastName());
            Console.WriteLine(emp2.getFirstName());
            Console.WriteLine(emp2.getRate());
            Console.WriteLine(emp2.getHours());
            */
            //property
            Console.WriteLine(WageEmployee.population);
            emp3.setEmpID(10);
            emp3.setFirtName("Shemp");
            emp3.setHours(2);
            emp3.setLastName("Fine");
            emp3.setRate("1000");
            emp3.setHours("2");




        }
}
}
