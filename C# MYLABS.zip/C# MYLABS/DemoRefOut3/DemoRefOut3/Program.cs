﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DemoRefOut3
{
    class Program
    {
        static void Main(string[] args)
        {
            string first = "intial value";
            string second = "inital value";
            Console.WriteLine(first);
            Console.WriteLine(second);
            refMethod(ref first, second);
            Console.WriteLine(first);
            Console.WriteLine(second);
        }
        //ref put 
        public static void refMethod(ref string arg1, string arg2)
        {
            arg1 = "changing first arg";
            arg2 = "changing second arg";
            Console.WriteLine(arg1);
            Console.WriteLine(arg2);
        }
    }
}
