﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Midterm
{
    class BankAccounts
    {
        static void Main(string[] args)
        {
            GoldAccount checking = new GoldAccount();
            checking.deposit(1000);
            checking.withdraw(2000);
            Console.WriteLine($" Bonzo Bank Saver: Balance  =  {checking.Balance}");

            SaverAccount saving = new SaverAccount();
            checking.deposit(4000);
            checking.withdraw(2000);
            Console.WriteLine($" Stooage Bank Saver: Balance  =  {checking.Balance}");
        }
    }
}
