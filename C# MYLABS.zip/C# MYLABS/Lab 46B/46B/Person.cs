﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab_46A
{
    abstract class Person
    {

        public static int Persons
    {
        get;set;
    }

        public string FirstName
        {
            get;set;
        }


        public string LastName
        { get; set; }

        protected Person()
        {
           
        }

        protected Person(string LastName, string FirstName)
        {
            this.LastName = LastName;
            this.FirstName = FirstName;
            Persons++;
        }
        virtual public string talk(string message)
        {
            Console.WriteLine("speaking  as a Person");
           // base.talk(message);

            return message="speaking as a Person";

        }

    }
}
