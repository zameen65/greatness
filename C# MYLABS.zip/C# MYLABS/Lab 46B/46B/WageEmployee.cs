﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab_46A
{
    class WageEmployee: Employee
    {
        public double wage
        { get; set; }

        public int hours
        { get; set; }

        public WageEmployee(string FirstName, string LastName, int EmpID, int hours, int wage)
            : base(LastName, FirstName, EmpID)
        {
            this.wage = wage;
            this.hours = hours;
        }
        public override double pay()
        {
            return Math.Round(wage * hours, 2);
        }
        public override string talk(string message)
        {
            base.talk(message);
            Console.WriteLine("Speaking as a WageEmployee");

            return message;

        }
    }
}
