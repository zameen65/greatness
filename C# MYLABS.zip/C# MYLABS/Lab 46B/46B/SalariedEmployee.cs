﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab_46A
{
    class SalariedEmployee : Employee
    {
        public double Annualsalary
        { get; set; }

        public SalariedEmployee(string FirstName, string LastName, int EmpID, double Annualsalary)
            :base(LastName, FirstName, EmpID)
        {
            this.Annualsalary = Annualsalary;
        }
        public override double pay()
        {
            return Annualsalary / 52.2;
        }
        public override string talk(string message)
        {
            base.talk ("speaking as a Salaried Employee");

            return message = "speaking as a Salaried Employee";

        }
    }
}
