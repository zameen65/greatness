﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab_46A
{
    class Employee : Person
    {
        public  int EmpID
        { get; set; }

        public Employee(string LastName, string FirstName, int EmpID)
                :base(LastName, FirstName)
        {
           
        }
        public virtual double pay()
        {
            return 0;
        }
        public override string talk(string message)
        {
            base.talk(message);
            Console.WriteLine("speaking as a Empolyee");
            return message;
        }


    }
}
