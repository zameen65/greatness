﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Lab42B;

namespace UsingAs
{
    class Checker2
    {
        public void check(object obj)
        {
            ClassA temp = obj as ClassA;
            // as tests for successful casting AFTER
            if (temp != null)
                Console.WriteLine("Variable was cast to ClassA.");
            else
                Console.WriteLine("Variable can't be cast to ClassA.");

            IMyInterface temp1 = obj as ClassA;
            if (temp1 != null)
                Console.WriteLine("Variable was cast to IMyInterface.");
            else
                Console.WriteLine("Variable can't be cast to IMyInterface.");

            object temp2 = obj as ClassA;
            if (temp2 != null)
                Console.WriteLine("Variable was cast to object.");
            else
                Console.WriteLine("Variable can't be cast to object.");

            ClassB temp3 = obj as ClassB;
            if (temp3 != null)
                Console.WriteLine("Variable was cast to ClassB.");
            else
                Console.WriteLine("Variable can't be cast to ClassB.");

            ClassC temp4 = obj as ClassC;
            if (temp4 != null)
                Console.WriteLine("Variable was cast to ClassC.");
            else
                Console.WriteLine("Variable can't be cast to ClassC.");

            ClassD temp5 = obj as ClassD;
            if (temp5 != null)
                Console.WriteLine("Variable was cast to ClassD.");
            else
                Console.WriteLine("Variable can't be cast to ClassD.");

            //this works, nulls are allowed
            MyStruct? temp6 = obj as MyStruct?;
            if (temp6 != null)
                Console.WriteLine("Variable wa cast to MyStruct.");
            else
                Console.WriteLine("Variable can't be cast to MyStruct.");

            //this doesn't work, nulls are NOT allowed
            //if nulls are not allowed, we can't test for null after "as" is complete
            //but our type is MyStruct NOT MyStruct ? In caseslike tis use "is"

            /*
            MyStruct temp7 = obj as MyStruct;
            if (temp6 != null)
                Console.WriteLine("Variable wa cast to MyStruct.");
            else
                Console.WriteLine("Variable can't be cast to MyStruct.");
            */

        }
    }
}
