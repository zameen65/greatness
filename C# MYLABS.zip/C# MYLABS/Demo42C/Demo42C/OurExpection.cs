﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab42B
    //anything .cs file that DemoLab must having a using statement
{
    class OurExpection : Exception
    {
        public OurExpection(string message)
            :base(message)
        {

        }
    }
}
