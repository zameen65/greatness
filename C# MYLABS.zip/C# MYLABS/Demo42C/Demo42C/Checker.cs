﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Lab42B;

namespace UsingIs
{
    class Checker
    {
        public void check(object obj)
        {
            if (obj is ClassA)
            // with "is", only attempt to do the cast if true is returned
            // we don't have to worry about null
            //wit "as" we HAVE to worry about null
            {
                Console.WriteLine("Variable can be cast to ClassA.");
                // if true do the cast, see p 196 because it's safe
                // DON'T ATTEMPT TO CAST UNLESS YOU TEST FIRST TO SEE IF IT'S 
                // GOING TO WORK
                ClassA testCast = (ClassA)obj; //EXPLICIT CAST
            }
            else
                Console.WriteLine("Variable can't be cast to ClassA.");

            if (obj is IMyInterface)
                Console.WriteLine("Variable can be cast to IMyInterface.");
            else
                Console.WriteLine("Variable can't be cast to IMyInterface.");

            if (obj is object)
                Console.WriteLine("Variable can be cast to object.");
            else
                Console.WriteLine("Variable can't be cast to object.");

            if (obj is ClassB)
                Console.WriteLine("Variable can be cast to ClassB.");
            else
                Console.WriteLine("Variable can't be cast to ClassB.");

            if (obj is ClassC)
                Console.WriteLine("Variable can be cast to ClassC.");
            else
                Console.WriteLine("Variable can't be cast to ClassC.");

            if (obj is ClassD)
                Console.WriteLine("Variable can be cast to ClassD.");
            else
                Console.WriteLine("Variable can't be cast to ClassD.");

            if (obj is MyStruct)
                Console.WriteLine("Variable can be cast to MyStruct.");
            else
                Console.WriteLine("Variable can't be cast to MyStruct.");
        }
    }
}
