﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab42B
{
    interface IMyInterface
    {
        //if uou forget to a specify a return tpe-void or some data type
        //the compiller will think it a constructor
        //and interfaces a
        void printString(string message);
    }
}
