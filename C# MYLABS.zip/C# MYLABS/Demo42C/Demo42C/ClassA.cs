﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab42B
{
    class ClassA : IMyInterface
    {
       public virtual void printString(string message)
        {
            Console.WriteLine(message);
        }
    }
}
