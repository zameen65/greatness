﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UsingIs;
using UsingAs;

namespace Lab42B
{
    class Program
    {
        static void doWork()
        {
            Checker c1 = new Checker();

            ClassA try1 = new ClassA();
            Console.WriteLine("Testing ClassA");
            c1.check(try1);
            Console.WriteLine();
            Console.WriteLine();


            ClassB try2 = new ClassB();
            Console.WriteLine("Testing ClassB");
            c1.check(try2);
            Console.WriteLine();
            Console.WriteLine();

            ClassC try3 = new ClassC();
            Console.WriteLine("Testing ClassC");
            c1.check(try3);
            Console.WriteLine();
            Console.WriteLine();

            ClassD try4 = new ClassD();
            Console.WriteLine("Testing ClassD");
            c1.check(try4);
            Console.WriteLine();
            Console.WriteLine();

            MyStruct try5 = new MyStruct();
            Console.WriteLine("Testing MyStruct");
            c1.check(try5);
            Console.WriteLine();
            Console.WriteLine();

            //instantiate Checker2
            Checker2 c2 = new Checker2();

            ClassA try10 = new ClassA();
            Console.WriteLine("Testing ClassA");
            c2.check(try10);
            Console.WriteLine();
            Console.WriteLine();


            ClassB try20 = new ClassB();
            Console.WriteLine("Testing ClassB");
            c2.check(try20);
            Console.WriteLine();
            Console.WriteLine();

            ClassC try30 = new ClassC();
            Console.WriteLine("Testing ClassC");
            c2.check(try30);
            Console.WriteLine();
            Console.WriteLine();

            ClassD try40 = new ClassD();
            Console.WriteLine("Testing ClassD");
            c2.check(try40);
            Console.WriteLine();
            Console.WriteLine();

            MyStruct try50 = new MyStruct();
            Console.WriteLine("Testing MyStruct");
            c2.check(try50);
            Console.WriteLine();
            Console.WriteLine();
            //throwing new expection
            // throw new Exception("we blew this up");

            //e=new Exception("string");
            throw new Exception("TGIF");
            //make my syestem throw
            /*
            int i = 0;
            int j = 8;
            int k = j / i;
            */

            
        }
        static void Main(string[] args)
        {
            try
            {
                doWork();
            }
            catch(Exception Ex)
            {
                Console.WriteLine(Ex.Message);
            }
            finally
            {
                Console.WriteLine("Sucess or failure we end up here");
            }
        }
    }
}
