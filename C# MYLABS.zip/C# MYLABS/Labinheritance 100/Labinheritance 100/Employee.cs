﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Labinheritance_100
{
    class Employee
    {
        //Field declarations
        public string lastName;
        public string firstName;
        public int employeeID;

        //noargs constructor
        public Employee()
        {
            lastName = "Howard";
            firstName = "Moe";
            //EmployeeID = 0; the constructor will set the defalut to zero
        }
        //other constructor
        public Employee(string lastName, string firstName, int employeeID)
        {
            this.lastName = lastName;
            this.firstName = firstName;
            this.employeeID = employeeID;
        }

        //getters / accessors
        public string getLastName()
        {
            return lastName;
        }

        public string getFirstName()
        {
            return firstName;
        }

        public int getEmployeeID()
        {
            return employeeID;
        }

        //setters / mutators
        public void setEmployeeID(int employeeID)
        {
            this.employeeID = employeeID;
        }

        public void setLastName(string lastName)
        {
            this.lastName = lastName;
        }

        public void setFirstName(string firstName)
        {
            this.firstName = firstName;
        }

        public virtual double pay()
        {
            return 0;
        }
    }
} 
