﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Labinheritance_100
{
    class WageEmployee : Employee
    {
        public double hours, rate;

        //noargs constructor
        public WageEmployee()
            : base()
        {

        }

        //other constructor
        public WageEmployee(string lastName, string firstName, int employeeID, double rate, double hours)
            : base(lastName, firstName, employeeID)
        {
            this.hours = hours;
            this.rate = rate;
        }

        //getter and setter
        public double getRate()
        {
            return rate;
        }

        public void setRate(double rate)
        {
            this.rate = rate;
        }

        public double getHours()
        {
            return hours;
        }

        public void setHours(double hours)
        {
            this.hours = hours;
        }

        public override double pay()
        {
            return Math.Round(rate * hours, 2);
        }
    }
}