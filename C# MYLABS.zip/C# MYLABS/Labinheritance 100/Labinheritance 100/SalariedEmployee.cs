﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Labinheritance_100
{
    class SalariedEmployee : Employee
    {
        public double salary;

        //noargs constructor
        public SalariedEmployee()
            : base()
        {

        }

        //other constructor
        public SalariedEmployee(string lastName, string firstName, int employeeID, double salary)
            : base(lastName, firstName, employeeID)
        {
            this.salary = salary;
        }

        //getter and setter
        public double getSalary()
        {
            return salary;
        }

        public void setSalary(double salary)
        {
            this.salary = salary;
        }

        public override double pay()
        {
            return Math.Round(salary / 52.2, 2);
        }
    }
}
