﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Labinheritance_100
{

     class Program
    {
        static void Main(string[] args)
        {
            SalariedEmployee salEmp1 = new SalariedEmployee("Fine", "Larry", 1, 200000);
            Console.WriteLine($"{salEmp1.lastName},{salEmp1.firstName}, {salEmp1.employeeID},{salEmp1.salary}");
            Console.WriteLine($"{salEmp1.lastName},{salEmp1.firstName}, {salEmp1.employeeID} makes {salEmp1.pay()} this week");


            Console.WriteLine();
            salEmp1.setEmployeeID(2);
            salEmp1.setLastName("Wenton");
            salEmp1.setFirstName("Harry");
            salEmp1.setSalary(300000);
            Console.WriteLine($"{salEmp1.getLastName()},{salEmp1.getFirstName()}, {salEmp1.getEmployeeID()},{salEmp1.getSalary()}");

            Console.WriteLine();
            WageEmployee wage1Emp1 = new WageEmployee("Howard", "Moe", 3, 1000, 20);
            Console.WriteLine($"{wage1Emp1.lastName},{wage1Emp1.firstName}, {wage1Emp1.employeeID},{wage1Emp1.hours}");
            Console.WriteLine($"{wage1Emp1.lastName},{wage1Emp1.firstName}, {wage1Emp1.employeeID} makes {wage1Emp1.pay()} this week");
            /*
            salEmp1.setEmployeeID(2);
            salEmp1.setLastName("Wenton");
            salEmp1.setFirstName("Harry");
            salEmp1.setSalary(300000);
            Console.WriteLine($"{salEmp1.getLastName()},{salEmp1.getFirstName()}, {salEmp1.getEmployeeID()},{salEmp1.getSalary()}");
            */
        }
    }
}
