﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Midterm
{
    class GoldAccount: IBankAccount
    {
        public double Balance
        { get; set; }
        public virtual  void  deposit(double dep)
        {
             Balance = Balance + dep;
        }
        public virtual bool  withdraw(double wth)
        {
            if (wth > Balance)

            {
                Console.WriteLine("Throwing insufficent fund");
                throw new InsufficentFundExpection("You don't have enough cash");
                return false;
             }

            else
            {
                Balance = Balance - wth;
                return true;
            }
        }
      
    }
}
