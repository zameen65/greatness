﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Midterm

{
    class InsufficentFundExpection : Exception
    {
        public InsufficentFundExpection()
            :base()
        {
        }
        public InsufficentFundExpection(string message)
           : base(message)
        {
            
        }
    }
}
