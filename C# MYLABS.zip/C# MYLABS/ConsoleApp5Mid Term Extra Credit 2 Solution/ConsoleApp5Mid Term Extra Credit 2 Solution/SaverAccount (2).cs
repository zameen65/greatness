﻿using System;
using MidTerm;
using BozoNationalBank;
using StoogeAmalgamatedBank;

namespace BozoNationalBank
{

    public class SaverAccount : IBankAccount
    {
        private decimal balance;
        public void Deposit(decimal amount)
        {
            balance += amount;
        }
        public bool Withdraw(decimal amount)
        {
            if (balance >= amount)
            {
                balance -= amount;
                return true;
            }
            Console.WriteLine("Throwing InsufficientFundsException on. " + this.GetType().ToString());
            throw new InsufficientFundsException("Withdrawal attempt failed. Make a deposit first");
        }
        public decimal Balance
        {
            get
            {
                return balance;
            }
        }
        public override string ToString()
        {
            return String.Format("Bozo Bank Saver: Balance = {0,6:C}", balance);
        }
    }
}
