using System;
using MidTerm;
using BozoNationalBank;
using StoogeAmalgamatedBank;

namespace MidTerm
{
   class MainEntryPoint
   {
      static void Main()
      {
         IBankAccount BozoAccount = new SaverAccount();
         IBankAccount StoogeAccount = new GoldAccount();
         try
         {
             //good withdrawals
             BozoAccount.Deposit(200);
             BozoAccount.Withdraw(100);             
             StoogeAccount.Deposit(500);
             StoogeAccount.Withdraw(400);             
             //bad withdrawals             
             BozoAccount.Withdraw(200);             ;
             StoogeAccount.Withdraw(200);
             
         }
         catch (InsufficientFundsException excp)
         {
             
             Console.WriteLine(excp.Message);
         }

         finally
         {
             Console.WriteLine(StoogeAccount.ToString());
             Console.WriteLine(BozoAccount.ToString());
         }
      }
   }
}







