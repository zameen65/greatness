﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab_46A
{
    abstract class Person
    {

        public static int Persons
    {
        get;set;
    }

        public string FirstName
        {
            get;set;
        }


        public string LastName
        { get; set; }
        //no args
        protected Person()
        {
           
        }
        //ovewrload constructor

        protected Person(string LastName, string FirstName)
        {
            this.LastName = LastName;
            this.FirstName = FirstName;
            Persons++;
        }
    }
}
