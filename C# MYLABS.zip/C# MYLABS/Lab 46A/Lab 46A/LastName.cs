﻿namespace Lab_46A
{
    internal class LastName
    {
    }
}