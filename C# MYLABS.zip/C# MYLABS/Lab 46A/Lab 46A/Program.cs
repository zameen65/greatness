﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab_46A
{
    class Program
    {
        static void Main(string[] args)
        {
            SalariedEmployee se1 = new SalariedEmployee("Ameen", "Zaki", 5, 500000);
            Console.WriteLine($"{se1.LastName},{se1.FirstName}, {se1.EmpID}  {se1.pay()} SalariedEmployee");
            Console.WriteLine($"{se1.LastName} makes {se1.pay()} per week");
            // Console.Write(se1.LastName);
            // Console.WriteLine(se1.FirstName);
            // Console.WriteLine(se1.EmpID);
            // Console.WriteLine(se1.Annualsalary);
            // Console.WriteLine(se1.pay());

           

            WageEmployee wage1Emp1 = new WageEmployee("Ameen", "Moe", 3, 1000, 20);
            Console.WriteLine($"{wage1Emp1.LastName},{wage1Emp1.FirstName}, {wage1Emp1.EmpID},{wage1Emp1.wage},{wage1Emp1.hours} Wage Employee");

            Console.WriteLine($"{wage1Emp1.LastName} makes {wage1Emp1.pay()} per week");



        }
    }
}
