﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DefineVaribles
{
    class Program
    {
        static void Main(string[] args)
        {   //declare 
            int int1, int2, int3;
            //assignment
            int1 = int2 = int3 = 10;
            //Write doesnt make a new line
            Console.Write("Value of int1 is ");
            Console.WriteLine(int1);
            Console.Write("Value of int2 is ");
            Console.WriteLine(int2);
            Console.Write("Value of int3 is ");
            Console.WriteLine(int3);
            int1 = 3;
            int2 = 6;
            int3 = 9;
            Console.Write("Value of int1 is ");
            Console.WriteLine(int1);
            Console.Write("Value of int2 is ");
            Console.WriteLine(int2);
            Console.Write("Value of int3 is ");
            Console.WriteLine(int3);
            long long1 = 3L;
            Console.Write("Value of long1 is ");
            Console.WriteLine(long1);
            float float1 = 3F;
            Console.Write("Value of float1 is ");
            Console.WriteLine(float1);
            decimal decimal1= 3M;
            Console.Write("Value of decimal is ");
            Console.WriteLine(decimal1);
        }
    }
}
