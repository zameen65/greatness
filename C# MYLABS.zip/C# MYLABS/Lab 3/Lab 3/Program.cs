﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab_3
{
    class Program
    {
        public static void Main()
        {
            OutputClass outC1 = new OutputClass("Niagra Falls!...");
            OutputClass outC3 = new OutputClass("Who's on 1st?...");
                OutputClass outC2 = new OutputClass();

            outC1.printString();
            outC3.printString();
                outC2.printString();
        }
    }
}
