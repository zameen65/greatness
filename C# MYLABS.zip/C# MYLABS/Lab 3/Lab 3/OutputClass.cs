﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab_3
{
    //helper 
    class OutputClass
    {
        private string myString;
        
        public OutputClass(string myStringP)
        {
           myString = myStringP;
            
        }
        public OutputClass()
        {
            //myString='default version'

        }
        public void printString()
        {
            Console.WriteLine("{0}", myString);
        }
    }
}
