begin tran -- sql server only
insert into dept
(deptno,deptname,mgrno,admrdept,location)
values('X14','IT',null,'E01','OMAHA');
insert into emp
(empno,lastname,midinit,firstnme,salary,edlevel)
values
('000999','HOWARD','S','CURLY', 100000, 16)
insert into emp
(empno,lastname,midinit,firstnme,salary,edlevel)
values
('001999','HOWARD','S','moe', 100000, 16)
insert into emp
(empno,lastname,midinit,firstnme,salary,edlevel)
values
('002999','fine','S','larry', 100000, 16)
insert into emp
(empno,lastname,midinit,firstnme,salary,edlevel,workdept)
values
('000666','fine','S','Curley Joe', 100000, 16, 'n01')
commit; --sql server & Oracle only