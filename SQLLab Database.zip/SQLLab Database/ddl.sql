CREATE TABLE DBO.EMP
             (EMPNO     				CHAR(6)     				NOT NULL,
              FIRSTNME  			VARCHAR(12) 			NOT NULL,
              MIDINIT   				CHAR(1)     				NOT NULL,
              LASTNAME  			VARCHAR(15)				NOT NULL,
              WORKDEPT  			CHAR(3)             						,
              PHONENO   			CHAR(4)             						,
              HIREDATE  			DATETIME               						,
              JOB       				CHAR(8)            						,
              EDLEVEL   			SMALLINT            						,
              SEX       				CHAR(1)             						,
              BIRTHDATE 			DATETIME                						,
              SALARY    			SMALLMONEY       						,
              BONUS     				SMALLMONEY        						,
              COMM      				SMALLMONEY        						,
              PRIMARY KEY(EMPNO) )         				;

  CREATE TABLE DBO.DEPT
              (DEPTNO    			 CHAR(3)     				NOT NULL	  ,
               DEPTNAME 			 VARCHAR(36) 			NOT NULL	  ,
               MGRNO     			 CHAR(6)           						  ,
               ADMRDEPT  			 CHAR(3)     				NOT NULL	  ,
               LOCATION  			 CHAR(16)           						  ,
               PRIMARY KEY(DEPTNO) )          	                 ;

  CREATE TABLE DBO.PROJ
               (PROJNO    			 CHAR(6)    				NOT NULL	,
               PROJNAME  			 VARCHAR(24) 			NOT NULL	,
               DEPTNO    			 CHAR(3)     				NOT NULL	,
               RESPEMP   			 CHAR(6)     				NOT NULL	,
               PRSTAFF   			 DECIMAL(5,2)        						,
               PRSTDATE  			 DATETIME            						,
               PRENDATE  			 DATETIME                						,
               MAJPROJ   			 CHAR(6)             						,
              PRIMARY KEY(PROJNO))         ;
