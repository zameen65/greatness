1. Start SQL Server Managemant Studio and connect to your instance.

2. You will need the appropriate permissions to run these statements.

3. Open CreateDB and make sure that your statement will run against the Master DB. Run the statement and, if it completes successfully, you may continue to the next step.

4. Open DDL and make sure that your statement will run against the SQLLAB DB. Run the statement and, if it completes successfully, you may continue to the next step.

5. Open LoadData and make sure that your statement will run against the SQLLAB DB. Run the statement and, if it completes successfully, you may continue to the next step.

6 Open OuterJoinData and make sure that your statement will run against the SQLLAB DB. Run the statement and, if it completes successfully, your setup is complete.
