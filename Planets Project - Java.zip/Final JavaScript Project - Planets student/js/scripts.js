
/* Grab the elements you need, you may do it all at the top or in each of your exercises */
var button1 = document.getElementById("sunpara");
var sunbtn = document.getElementById("sun");
var mercbtn = document.getElementById("mercurybtn");
var juptxt = document.getElementById("jupitertxt");
var jupbtn = document.getElementById("jupiterbtn");


/* create the code for hiding your paragraph when you roll over the sun, 
remove the mouse and bring the paragraph back.  Use your event handlers 
 */
function removebutton1()
{
    button1.setAttribute("class", "disappear");
}

function addbutton1()
{
    button1.setAttribute("class", "");
}

sunbtn.onmouseover = removebutton1;
sunbtn.onmouseout = addbutton1;


var mercuryInfo =
    {
        "facts": [
            "Mercury is the smallest planet.",
            "Mercury is the messenger god.",
            "Mercury is red.",
            "Mercury is also in thermometers."
        ]
    };

var mercFactCount = mercuryInfo.facts.length;
function mercuryAlert()
{
    var alertString = "";
    for (var i = 0; i < mercFactCount; i++)
    {
        alertString += mercuryInfo.facts[i] + "\n";
    }
    alert(mercuryInfo);
}

mercbtn.addEventListener("click", mercuryAlert, false);




function jupiterFacts() {
    juptxt.innerHTML = "";

    for (var i = 0; i < jupiterFactCount; i++) {
        if (jupiterInfo.facts[i] === "has a big storm") {
            juptxt.innerHTML += '<p style="color: red;">Jupiter: has a big storm</p>';
        }
        else if (jupiterInfo.facts[i] === "has four moons") {
            juptxt.innerHTML += '<p style="font-size: 27px;">Jupiter: has four moons</p>'
        }
        else {
            juptxt.innerHTML += "<p>Jupiter: " + jupiterInfo.facts[i] + "</p>";
        }
    }
}

var jupiterInfo = 
    {
        "facts": [
            "is the largest planet",
            "has a big storm",
            "has four moons",
            "spins faster than any other planet",
            "is 438,682,810 miles from the sun"
        ]
    }
var jupiterFactCount = jupiterInfo.facts.length;
jupbtn.addEventListener("click", jupiterFacts, false);

/* Create an object holding one SIMPLE array of 4 pieces of information about Mercury.  Show all facts in an alert.
 Create a function that when a button is clicked will pop up the Mercury information formatted nicely, like the instructor's...



Mercury is the smallest planet.
Mercury is the messanger god.
Mercury is red.
Mercury is also in thermometers

Use an event listener in this one
 */




/* Create a JSON object of Jupiter information.  You might want to put an array in your object for the "looping" part of this!
When someone clicks the button, loop through all of the information, but in one chunk display it all in a paragraph ABOVE the button.

Make the sentence: has a big storm - red
Make the sentence: has four moons - bigger than the rest

is the largest planet
has a big storm
has four moons
spins faster than any other planet
is 483,682,810 miles from the sun
*/


/* BEFORE you zip it all up - RENAME your js file to a txt file.  It will not go through email */